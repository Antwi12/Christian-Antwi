@echo off
echo.
echo =======================================
echo   User-level Flask Installation
echo =======================================
echo.

echo Installing Flask to user directory (no admin required)...
py -m pip install --user flask flask-cors requests beautifulsoup4 feedparser APScheduler dicttoxml python-dateutil

echo.
echo Testing Flask import...
py -c "import flask; print('SUCCESS: Flask version', flask.__version__)"

if errorlevel 1 (
    echo Still not working. Let's check what's going on...
    echo.
    echo Python version:
    py --version
    echo.
    echo Python executable location:
    py -c "import sys; print('Python exe:', sys.executable)"
    echo.
    echo Site packages:
    py -c "import site; print('Site packages:', site.getsitepackages())"
    echo.
    echo User site packages:
    py -c "import site; print('User site:', site.getusersitepackages())"
    echo.
    echo Current Python path:
    py -c "import sys; [print(p) for p in sys.path]"
    pause
    exit /b 1
)

echo Flask is working! Setting up database...
py setup.py

echo.
echo Starting server...
py app.py

pause