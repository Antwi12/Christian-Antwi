@echo off
echo.
echo =======================================
echo   Ghana-Square News - Quick Fix
echo =======================================
echo.

REM Find Python
set PYTHON_CMD=

py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    goto :quick_fix
)

python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    goto :quick_fix
)

echo Error: Python not found!
pause
exit /b 1

:quick_fix
echo Found Python: %PYTHON_CMD%

echo.
echo Installing Flask directly...
%PYTHON_CMD% -m pip install Flask

echo.
echo Installing Flask-CORS...
%PYTHON_CMD% -m pip install Flask-CORS

echo.
echo Installing requests...
%PYTHON_CMD% -m pip install requests

echo.
echo Installing beautifulsoup4...
%PYTHON_CMD% -m pip install beautifulsoup4

echo.
echo Installing additional packages...
%PYTHON_CMD% -m pip install feedparser APScheduler dicttoxml python-dateutil

echo.
echo Testing Flask import with detailed output...
%PYTHON_CMD% -c "try:
    import flask
    print('SUCCESS: Flask version', flask.__version__)
    from flask import Flask
    app = Flask(__name__)
    print('SUCCESS: Flask app creation works!')
    import flask_cors
    print('SUCCESS: Flask-CORS imported!')
    import requests
    print('SUCCESS: Requests imported!')
    import bs4
    print('SUCCESS: BeautifulSoup imported!')
    print('=== ALL TESTS PASSED ===')
except Exception as e:
    print('ERROR:', e)
    import sys
    print('Python version:', sys.version)
    print('Python path:', sys.path)
    exit(1)"

if errorlevel 1 (
    echo.
    echo Flask test failed. Let's try a different approach...
    echo Attempting to run the server directly...
    
    echo.
    echo Creating database...
    %PYTHON_CMD% setup.py
    
    echo.
    echo Trying to start server (this will show the real error)...
    %PYTHON_CMD% app.py
    
    pause
    exit /b 1
)

echo.
echo Creating database...
%PYTHON_CMD% setup.py

echo.
echo ========================================
echo Quick fix completed successfully!
echo Now try: start_server.bat
echo ========================================
pause