import dicttoxml
with open('news_results.xml', 'wb') as f:
    xml_data = dicttoxml.dicttoxml(json_data)
    f.write(xml_data)
import sqlite3
conn = sqlite3.connect('news.db')
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        url TEXT UNIQUE,
        publishedAt TEXT,
        source TEXT,
        topic TEXT
    )
''')
for article in articles:
    cursor.execute('INSERT OR IGNORE INTO articles VALUES (NULL, ?, ?, ?, ?, ?, ?)',
                   (title, description, url, publishedAt, source, topic))
conn.commit()
conn.close()
from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route('/getnews', methods=['GET'])
def get_news():
    topic = request.args.get('topic')
    articles = query_news_api(topic)
    xml_response = dicttoxml.dicttoxml(articles)
    return app.response_class(response=xml_response, mimetype='application/xml')

if __name__ == '__main__':
    app.run()
