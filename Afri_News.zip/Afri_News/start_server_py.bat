@echo off
echo.
echo =======================================
echo   Ghana-Square News Server Startup
echo =======================================
echo.

REM Try different Python commands
py --version >nul 2>&1
if errorlevel 0 (
    set PYTHON_CMD=py
    goto :python_found
)

python3 --version >nul 2>&1
if errorlevel 0 (
    set PYTHON_CMD=python3
    goto :python_found
)

python --version >nul 2>&1
if errorlevel 0 (
    set PYTHON_CMD=python
    goto :python_found
)

echo Error: Python is not found. Trying common installation paths...

REM Try common Python installation paths
if exist "C:\Program Files\Python311\python.exe" (
    set PYTHON_CMD="C:\Program Files\Python311\python.exe"
    goto :python_found
)

if exist "C:\Program Files\Python310\python.exe" (
    set PYTHON_CMD="C:\Program Files\Python310\python.exe"
    goto :python_found
)

if exist "C:\Program Files\Python39\python.exe" (
    set PYTHON_CMD="C:\Program Files\Python39\python.exe"
    goto :python_found
)

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    goto :python_found
)

if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    goto :python_found
)

if exist "%LOCALAPPDATA%\Programs\Python\Python39\python.exe" (
    set PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
    goto :python_found
)

echo Error: Python installation not found in common locations
echo Please install Python from https://python.org or add it to PATH
pause
exit /b 1

:python_found
echo Found Python: %PYTHON_CMD%
%PYTHON_CMD% --version

REM Check if virtual environment exists
if not exist "venv" (
    echo Creating virtual environment...
    %PYTHON_CMD% -m venv venv
    if errorlevel 1 (
        echo Error: Failed to create virtual environment
        pause
        exit /b 1
    )
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install dependencies if requirements.txt exists
if exist "requirements.txt" (
    echo Installing/updating dependencies...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo Warning: Some dependencies might not have installed correctly
    )
)

REM Run setup script if database doesn't exist
if not exist "news.db" (
    echo Running initial setup...
    %PYTHON_CMD% setup.py
)

REM Start the Flask application
echo.
echo Starting Flask application...
echo Server will be available at: http://localhost:5000
echo API Health Check: http://localhost:5000/api/health
echo.
echo Press Ctrl+C to stop the server
echo.

%PYTHON_CMD% app.py

echo.
echo Server stopped.
pause