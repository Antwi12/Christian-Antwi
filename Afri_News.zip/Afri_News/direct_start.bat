@echo off
echo.
echo =======================================
echo   Direct Server Start (Bypass PATH issues)
echo =======================================
echo.

REM Try to find Python installation directly
set PYTHON_EXE=

REM Check common Python 3.13 locations
if exist "C:\Users\user\AppData\Local\Programs\Python\Python313\python.exe" (
    set PYTHON_EXE="C:\Users\user\AppData\Local\Programs\Python\Python313\python.exe"
    goto :found_python
)

if exist "C:\Program Files\Python313\python.exe" (
    set PYTHON_EXE="C:\Program Files\Python313\python.exe"
    goto :found_python
)

if exist "C:\Program Files (x86)\Python313\python.exe" (
    set PYTHON_EXE="C:\Program Files (x86)\Python313\python.exe"
    goto :found_python
)

REM Try py launcher as fallback
py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_EXE=py
    goto :found_python
)

echo Could not find Python installation!
echo Please run: diagnose.bat to troubleshoot
pause
exit /b 1

:found_python
echo Found Python: %PYTHON_EXE%
%PYTHON_EXE% --version

echo.
echo Installing Flask to this specific Python installation...
%PYTHON_EXE% -m pip install flask flask-cors requests beautifulsoup4

echo.
echo Testing Flask import...
%PYTHON_EXE% -c "import flask; print('SUCCESS: Flask version', flask.__version__)"

if errorlevel 1 (
    echo Flask import still failed!
    echo Running full diagnostic...
    pause
    call diagnose.bat
    exit /b 1
)

echo.
echo Setting up database...
%PYTHON_EXE% setup.py

echo.
echo =======================================
echo Starting Ghana-Square News Server...
echo =======================================
echo.
echo Server will be available at: http://localhost:5000
echo Press Ctrl+C to stop the server
echo.

%PYTHON_EXE% app.py

echo.
echo Server stopped.
pause