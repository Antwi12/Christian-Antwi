// Buttons
const generalBtn = document.getElementById("general");
const businessBtn = document.getElementById("business");
const sportsBtn = document.getElementById("sport");
const entertainmentBtn = document.getElementById("entertainment");
const technologyBtn = document.getElementById("technology");
const searchBtn = document.getElementById("searchBtn");
const darkToggle = document.getElementById("darkToggle");

// Input/Output
const newsQuery = document.getElementById("newsQuery");
const newsType = document.getElementById("newsType");
const newsdetails = document.getElementById("newsdetails");

// News store
let newsDataArr = [];

// API Configuration
const API_BASE = 'http://localhost:5001/api'; // Change to your deployed URL

const apiKeys = {
    gnews: 'YOUR_GNEWS_API_KEY',
    newsdata: 'YOUR_NEWSDATA_IO_API_KEY',
    newsapi: 'YOUR_NEWSAPI_KEY'
};

async function searchNews() {
    const query = document.getElementById('searchBar').value;
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = 'Loading...';

    const apis = [
        `https://gnews.io/api/v4/search?q=${query}&token=${apiKeys.gnews}&max=25`,
        `https://newsdata.io/api/1/news?apikey=${apiKeys.newsdata}&q=${query}&language=en&limit=25`,
        `https://newsapi.org/v2/everything?q=${query}&apiKey=${apiKeys.newsapi}&language=en&pageSize=25`
    ];

    let allNews = [];

    for (const apiUrl of apis) {
        try {
            const response = await fetch(apiUrl);
            const data = await response.json();
            const articles = data.articles || data.results || data.items || [];
            allNews = allNews.concat(articles.map(article => ({
                title: article.title,
                description: article.description || article.content,
                url: article.url,
                image: article.image || article.urlToImage || 'https://via.placeholder.com/150'
            })));
        } catch (error) {
            console.error(`Error fetching from ${apiUrl}:`, error);
        }
    }

    resultsDiv.innerHTML = '';
    allNews.slice(0, 75).forEach(news => {
        const div = document.createElement('div');
        div.className = 'news-item';
        div.innerHTML = `
            <h3>${news.title}</h3>
            <img src="${news.image}" alt="${news.title}" style="max-width: 100%;">
            <p>${news.description}</p>
            <a href="${news.url}" target="_blank">Read more</a>
        `;
        resultsDiv.appendChild(div);
    });
}
// Dark mode functionality
darkToggle.addEventListener("click", () => {
    document.body.classList.toggle('dark-mode');
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => card.classList.toggle('dark-mode'));
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => alert.classList.toggle('dark-mode'));
});

// Flask Backend API endpoints (Google News RSS and Yahoo via Flask)
function buildGoogleRSS(category) {
    if (category === 'general') {
        // Use Yahoo via Flask backend
        return `${API_BASE}/news`;
    } else {
        // Use Google News via Flask backend
        return `${API_BASE}/google-news/${category}`;
    }
}

// Search using Flask backend
function buildSearchRSS(query) {
    return `${API_BASE}/search/${encodeURIComponent(query)}`;
}

// Show loading spinner
function showLoading() {
    newsdetails.innerHTML = `
        <div class="col-12">
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    `;
}

// 👇 Category buttons
generalBtn.addEventListener("click", () => fetchNews("general"));
businessBtn.addEventListener("click", () => fetchNews("business"));
sportsBtn.addEventListener("click", () => fetchNews("sports"));
technologyBtn.addEventListener("click", () => fetchNews("technology"));
entertainmentBtn.addEventListener("click", () => fetchNews("entertainment"));

// 🔍 Search bar with categorized search option
searchBtn.addEventListener("click", () => {
    const query = newsQuery.value.trim();
    if (!query) return;
    
    // Check if user wants categorized search (add checkbox in HTML for this)
    const categorizedSearch = document.getElementById('categorizedSearch');
    
    if (categorizedSearch && categorizedSearch.checked) {
        newsType.innerHTML = `<h4>Categorized Search: ${query}</h4>`;
        fetchCategorizedNews(query);
    } else {
        newsType.innerHTML = `<h4>Search: ${query}</h4>`;
        fetchSearchNews(query);
    }
});

// Enter key for search
newsQuery.addEventListener("keypress", (e) => {
    if (e.key === 'Enter') {
        searchBtn.click();
    }
});

// 📰 Load default
window.onload = () => {
    newsType.innerHTML = "<h4>Top Headlines</h4>";
    fetchNews("general");
};

function fetchNews(category) {
    showLoading();
    newsType.innerHTML = `<h4>${category.charAt(0).toUpperCase() + category.slice(1)} News</h4>`;
    const url = buildGoogleRSS(category);

    fetch(url)
        .then(response => response.json())
        .then(data => {
            newsDataArr = data.items || [];
            displayNews();
        })
        .catch(error => {
            console.error("Error fetching news:", error);
            newsdetails.innerHTML = `<div class="alert alert-danger">Failed to load ${category} news.</div>`;
        });
}

function displayNews() {
    console.log(`Displaying ${newsDataArr.length} articles`);
    
    if (newsDataArr.length === 0) {
        newsdetails.innerHTML = `<div class="col-12 text-center">No news found.</div>`;
        return;
    }

    let html = '';
    newsDataArr.forEach((news, index) => {
        console.log(`Article ${index + 1}:`, {
            title: news.title?.substring(0, 50),
            image: news.image,
            image_url: news.image_url,
            thumbnail: news.thumbnail,
            enclosure: news.enclosure
        });
        // Try multiple image sources - this is the key fix!
        let imageUrl = null;
        
        // Check various image properties that different RSS feeds use
        if (news.image && news.image !== "default.jpg") {
            imageUrl = news.image;
        } else if (news.image_url && news.image_url !== "default.jpg") {
            imageUrl = news.image_url;
        } else if (news.enclosure && news.enclosure.link && news.enclosure.link !== "default.jpg") {
            imageUrl = news.enclosure.link;
        } else if (news.thumbnail && news.thumbnail !== "default.jpg") {
            imageUrl = news.thumbnail;
        } else if (news.description) {
            imageUrl = extractImageFromContent(news.description);
        } else if (news.content) {
            imageUrl = extractImageFromContent(news.content);
        }
        
        // Force image to show - use local base64 fallback
        const localPlaceholder = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWU0MGFmIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+";
        const finalImageUrl = imageUrl || localPlaceholder;
        
        console.log(`Article image URL: ${finalImageUrl.substring(0, 50)}...`);
        
        // Add source badge for better identification
        let sourceBadge = '';
        if (news.source) {
            const badgeColor = news.source.includes('BBC') ? 'badge-danger' : 
                              news.source.includes('Yahoo') ? 'badge-warning' : 'badge-info';
            sourceBadge = `<span class="badge ${badgeColor} mb-2">${news.source}</span><br>`;
        }
        
        html += `
            <div class="card mb-3">
                <img src="${finalImageUrl}" class="card-img-top" alt="News Image" 
                     style="height: 200px; object-fit: cover; background-color: #f8f9fa;"
                     onerror="this.src='${localPlaceholder}'">
                <div class="card-body">
                    ${sourceBadge}
                    <h5 class="card-title">${news.title}</h5>
                    <p class="card-text text-muted" style="font-size: 0.9em;">
                        ${news.pubDate || news.published || ''}
                    </p>
                    <p class="card-text">${news.description || ''}</p>
                    <a href="${news.link}" class="btn btn-primary" target="_blank">Read more on ${news.source || 'source'}</a>
                </div>
            </div>
        `;
    });
    newsdetails.innerHTML = html;
}


// Image placeholder constants - centralized for consistency
const IMAGE_PLACEHOLDERS = {
    loading: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23f8f9fa'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' fill='%236c757d' font-family='Arial'%3ELoading...%3C/text%3E%3C/svg%3E",
    noImage: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23e9ecef'/%3E%3Cg transform='translate(150,100)'%3E%3Ccircle cx='0' cy='-20' r='25' fill='%236c757d' opacity='0.5'/%3E%3Crect x='-15' y='-15' width='30' height='20' fill='white'/%3E%3Ccircle cx='-8' cy='-8' r='3' fill='%236c757d'/%3E%3Cpolygon points='-15,5 -5,-5 5,-2 15,8 -15,8' fill='%236c757d' opacity='0.7'/%3E%3C/g%3E%3Ctext x='50%25' y='75%25' text-anchor='middle' fill='%236c757d' font-family='Arial' font-size='14'%3ENo Image%3C/text%3E%3C/svg%3E",
    error: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23f8d7da'/%3E%3Cg transform='translate(150,100)'%3E%3Ccircle cx='0' cy='0' r='25' fill='%23dc3545' opacity='0.8'/%3E%3Ctext x='0' y='7' text-anchor='middle' fill='white' font-family='Arial' font-size='24' font-weight='bold'%3E!%3C/text%3E%3C/g%3E%3Ctext x='50%25' y='75%25' text-anchor='middle' fill='%23721c24' font-family='Arial' font-size='14'%3EImage Error%3C/text%3E%3C/svg%3E"
};

// Utility function for consistent image handling across all functions
function setupImageWithFallbacks(imageElement, imageUrl, title = "News Image") {
    imageElement.setAttribute("alt", title);
    imageElement.src = IMAGE_PLACEHOLDERS.loading;
    
    if (imageUrl) {
        // Try to load the actual image
        const tempImg = new Image();
        tempImg.onload = function() {
            imageElement.src = imageUrl;
        };
        tempImg.onerror = function() {
            imageElement.src = IMAGE_PLACEHOLDERS.noImage;
        };
        tempImg.src = imageUrl;
    } else {
        imageElement.src = IMAGE_PLACEHOLDERS.noImage;
    }
    
    // Final fallback for any other errors
    imageElement.onerror = function() {
        if (this.src !== IMAGE_PLACEHOLDERS.error) {
            this.src = IMAGE_PLACEHOLDERS.error;
        }
    };
}

// Enhanced image extraction function
function extractImageFromContent(content) {
    if (!content) return null;
    
    // Clean the content first
    const cleanContent = content.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    
    // Look for img tags with various quote styles
    const imgPatterns = [
        /<img[^>]+src=["']([^"']+)["'][^>]*>/i,
        /<img[^>]+src=([^\s>]+)[^>]*>/i,
        /src=["']([^"']*\.(?:jpg|jpeg|png|gif|webp|svg)[^"']*)/i,
        /src=([^\s>]+\.(?:jpg|jpeg|png|gif|webp|svg))/i
    ];
    
    for (const pattern of imgPatterns) {
        const match = cleanContent.match(pattern);
        if (match && match[1]) {
            let imageUrl = match[1];
            // Clean up the URL
            imageUrl = imageUrl.replace(/^\/\//, 'https://');
            if (imageUrl.startsWith('http')) {
                return imageUrl;
            }
        }
    }
    
    // Look for direct image URLs with more comprehensive patterns
    const urlPatterns = [
        /https?:\/\/[^\s<>"']+\.(?:jpg|jpeg|png|gif|webp|svg)(?:\?[^\s<>"']*)?/i,
        /https?:\/\/[^\s<>"']*(?:image|img|photo|picture|thumbnail|media|cdn|static)[^\s<>"']*\.(?:jpg|jpeg|png|gif|webp|svg)/i,
        /https?:\/\/[^\s<>"']*\/[^\s<>"']*(?:\.jpg|\.jpeg|\.png|\.gif|\.webp|\.svg)/i,
        /(?:url|href|link|src)\s*[=:]\s*["']?([^"'\s<>]+\.(?:jpg|jpeg|png|gif|webp|svg))/i,
        /https?:\/\/[^\s<>"']*googleusercontent[^\s<>"']*\.(?:jpg|jpeg|png|gif|webp)/i,
        /https?:\/\/[^\s<>"']*gstatic[^\s<>"']*\.(?:jpg|jpeg|png|gif|webp)/i,
        /https?:\/\/[^\s<>"']*\.amazonaws[^\s<>"']*\.(?:jpg|jpeg|png|gif|webp)/i
    ];
    
    for (const pattern of urlPatterns) {
        const match = cleanContent.match(pattern);
        if (match) {
            let imageUrl = match[1] || match[0];
            // Clean up the URL
            imageUrl = imageUrl.replace(/['">\s].*$/, ''); // Remove trailing quotes, brackets, etc.
            imageUrl = imageUrl.replace(/^\/\//, 'https://');
            if (imageUrl.startsWith('http') && imageUrl.includes('.')) {
                return imageUrl;
            }
        }
    }
    
    // Look for base64 images as last resort
    const base64Match = cleanContent.match(/data:image\/[^;]+;base64,([^"'\s<>]+)/i);
    if (base64Match && base64Match[0]) {
        return base64Match[0];
    }
    
    return null;
}

// Working RSS feed fetcher with reliable image handling
async function fetchWorkingRSSFeed(category) {
    try {
        // Try primary RSS feed
        let url = buildWorkingRSS(category);
        let response = await fetch(url);
        let data = await response.json();
        
        // If primary fails, try backup
        if (!data.items || data.items.length === 0) {
            console.log(`Primary RSS failed for ${category}, trying backup...`);
            url = buildBackupRSS(category);
            response = await fetch(url);
            data = await response.json();
        }
        
        if (!data.items || data.items.length === 0) {
            newsDataArr = [];
            displayNews();
            return;
        }
        
        // Process items with enhanced image extraction
        const processedItems = data.items.map((item) => {
            let imageUrl = null;
            
            // Try multiple sources for images - BBC and CNN feeds typically have good image support
            if (item.enclosure && item.enclosure.link) {
                imageUrl = item.enclosure.link;
                console.log(`Found image from enclosure: ${imageUrl}`);
            } else if (item.thumbnail) {
                imageUrl = item.thumbnail;
                console.log(`Found image from thumbnail: ${imageUrl}`);
            } else if (item.description) {
                imageUrl = extractImageFromContent(item.description);
                if (imageUrl) console.log(`Extracted image from description: ${imageUrl}`);
            } else if (item.content) {
                imageUrl = extractImageFromContent(item.content);
                if (imageUrl) console.log(`Extracted image from content: ${imageUrl}`);
            }
            
            // Additional attempts to find images
            if (!imageUrl) {
                // Try to extract from title or summary
                const fullContent = (item.description || '') + ' ' + (item.content || '') + ' ' + (item.summary || '');
                imageUrl = extractImageFromContent(fullContent);
                if (imageUrl) console.log(`Extracted image from full content: ${imageUrl}`);
                else console.log(`No image found for article: ${item.title?.substring(0, 50)}...`);
            }
            
            // Clean description
            const cleanDescription = item.description ? 
                item.description.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() : '';
            
            return {
                ...item,
                image: imageUrl,
                image_url: imageUrl,
                enclosure: imageUrl ? { link: imageUrl } : null,
                description: cleanDescription
            };
        });
        
        newsDataArr = processedItems.slice(0, 20); // Limit to 20 articles
        displayNews();
        
    } catch (error) {
        console.error('Error fetching working RSS feed:', error);
        newsdetails.innerHTML = `<div class="alert alert-danger">Failed to load ${category} news. Please try again later.</div>`;
    }
}

// 🔄 Fetch News via Flask Backend (Google News RSS and Yahoo)
async function fetchNews(category) {
    try {
        showLoading();
        
        // Set category title
        const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
        if (category === "general") {
            newsType.innerHTML = `<h4>Top Headlines</h4>`;
        } else {
            newsType.innerHTML = `<h4>${categoryTitle} News</h4>`;
        }
        
        // Use Flask backend API
        const url = buildGoogleRSS(category);
        console.log(`Fetching from Flask API: ${url}`);
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        newsDataArr = data || [];
        console.log(`Loaded ${newsDataArr.length} articles for ${category}`);
        
        displayNews();
        
    } catch (error) {
        console.error('Error fetching news from Flask backend:', error);
        newsdetails.innerHTML = `<div class="alert alert-danger">
            <h5>Backend Server Not Running</h5>
            <p>Please start the Flask server first:</p>
            <code>python app.py</code>
            <br><small>Error: ${error.message}</small>
        </div>`;
    }
}

// 🔎 Search News via Flask Backend
async function fetchSearchNews(query) {
    try {
        showLoading();
        
        const url = buildSearchRSS(query);
        console.log(`Searching via Flask API: ${url}`);
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        newsDataArr = data || [];
        console.log(`Found ${newsDataArr.length} search results for "${query}"`);
        
        displayNews();
        
    } catch (error) {
        console.error('Error searching news via Flask backend:', error);
        newsdetails.innerHTML = `<div class="alert alert-danger">
            <h5>Backend Server Not Running</h5>
            <p>Please start the Flask server to search news.</p>
            <small>Error: ${error.message}</small>
        </div>`;
    }
}

// 🗂️ Categorized Search News
async function fetchCategorizedNews(query) {
    try {
        showLoading();
        newsType.innerHTML = `<h4>Categorized Search: ${query}</h4>`;
        
        // Try Flask backend for categorized search
        const response = await fetch(`${API_BASE}/categorized-search/${encodeURIComponent(query)}`);
        if (response.ok) {
            const data = await response.json();
            displayCategorizedNews(data);
            return;
        }
        
        // Fallback: fetch each category separately
        await fetchCategorizedFallback(query);
        
    } catch (error) {
        console.error('Categorized search error:', error);
        await fetchCategorizedFallback(query);
    }
}

// BBC-powered categorized search
async function fetchCategorizedFallback(query) {
    console.log(`🔍 BBC Categorized Search for: "${query}"`);
    const categories = ['business', 'sports', 'technology', 'entertainment'];
    const categorizedData = {};
    
    for (const category of categories) {
        try {
            console.log(`Searching BBC ${category} for: "${query}"`);
            
            // Use our BBC search endpoint with category filtering
            const response = await fetch(`/api/search/${encodeURIComponent(query)}`);
            const searchResults = await response.json();
            
            // Filter results for this specific category
            const categoryResults = searchResults.filter(item => {
                const source = (item.source || '').toLowerCase();
                const searchCategory = (item.search_category || '').toLowerCase();
                const title = (item.title || '').toLowerCase();
                const description = (item.description || '').toLowerCase();
                
                // Check if item belongs to this category
                return (
                    source.includes(category) ||
                    searchCategory.includes(category) ||
                    (category === 'business' && (source.includes('business') || title.includes('business') || description.includes('finance') || description.includes('economy'))) ||
                    (category === 'sports' && (source.includes('sport') || title.includes('sport') || description.includes('football') || description.includes('basketball'))) ||
                    (category === 'technology' && (source.includes('technology') || source.includes('tech') || title.includes('tech') || description.includes('technology'))) ||
                    (category === 'entertainment' && (source.includes('entertainment') || title.includes('entertainment') || description.includes('music') || description.includes('movie')))
                );
            }).slice(0, 5); // Limit to 5 per category
            
            // Process items to ensure proper image handling
            const processedItems = categoryResults.map(item => {
                // Ensure every item has proper image data
                if (!item.image || item.image === 'default.jpg') {
                    // Use BBC category-specific placeholder
                    const placeholders = {
                        'business': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMDA1OTY5O3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjQiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QlVTSU5FU1M8L3RleHQ+PHRleHQgeD0iNTAlIiB5PSI3MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+",
                        'sports': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojZGMyNjI2O3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDIFNQT1JUID48L3RleHQ+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5TUE9SVFM8L3RleHQ+PHRleHQgeD0iNTAlIiB5PSI3MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+",
                        'technology': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojN2MzYWVkO3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+VEVDSE5PTE9HWTwvdGV4dD48dGV4dCB4PSI1MCUiIHk9IjcwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+TkVXUzwvdGV4dD48L3N2Zz4=",
                        'entertainment': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojZWE1ODBjO3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+RU5URVJUQUlOTUVOVDwvdGV4dD48dGV4dCB4PSI1MCUiIHk9IjcwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+TkVXUzwvdGV4dD48L3N2Zz4="
                    };
                    const placeholder = placeholders[category] || placeholders['business'];
                    item.image = placeholder;
                    item.image_url = placeholder;
                    item.enclosure = { link: placeholder };
                }
                
                // Ensure source shows BBC
                if (!item.source || !item.source.toLowerCase().includes('bbc')) {
                    item.source = `BBC ${category.charAt(0).toUpperCase() + category.slice(1)}`;
                }
                
                return item;
            });
            
            categorizedData[category] = processedItems;
            console.log(`✅ Found ${processedItems.length} BBC ${category} articles for "${query}"`);
            
        } catch (error) {
            console.error(`❌ Error fetching BBC ${category} news:`, error);
            categorizedData[category] = [];
        }
    }
    
    console.log(`📊 BBC Categorized Search Complete:`, Object.keys(categorizedData).map(cat => `${cat}: ${categorizedData[cat].length} articles`));
    displayCategorizedNews(categorizedData);
}

// Display categorized news results
function displayCategorizedNews(categorizedData) {
    newsdetails.innerHTML = "";
    
    if (!categorizedData || Object.keys(categorizedData).length === 0) {
        const alertClass = document.body.classList.contains('dark-mode') ? 'alert alert-info dark-mode' : 'alert alert-info';
        newsdetails.innerHTML = `<div class='col-12'><div class='${alertClass}'><h5>No categorized news found.</h5></div></div>`;
        return;
    }
    
    let html = '';
    
    // Create tabs for categories
    html += `
        <div class="col-12">
            <ul class="nav nav-tabs mb-3" id="categoryTabs" role="tablist">
    `;
    
    Object.keys(categorizedData).forEach((category, index) => {
        const isActive = index === 0 ? 'active' : '';
        const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
        html += `
            <li class="nav-item" role="presentation">
                <button class="nav-link ${isActive}" id="${category}-tab" data-bs-toggle="tab" data-bs-target="#${category}-content" type="button" role="tab">
                    ${categoryTitle} (${categorizedData[category].length})
                </button>
            </li>
        `;
    });
    
    html += `
            </ul>
            <div class="tab-content" id="categoryTabContent">
    `;
    
    // Create tab content for each category
    Object.keys(categorizedData).forEach((category, index) => {
        const isActive = index === 0 ? 'show active' : '';
        html += `
            <div class="tab-pane fade ${isActive}" id="${category}-content" role="tabpanel">
                <div class="row">
        `;
        
        categorizedData[category].forEach(news => {
            // Try multiple image sources with better extraction
            let image = news.image || news.image_url || news.enclosure?.link;
            
            // If still no image, try extracting from description again
            if (!image && news.description) {
                image = extractImageFromContent(news.description);
            }
            
            // Format date
            let pubDate = "Unknown date";
            if (news.pubDate) {
                pubDate = news.pubDate.split(" ")[0];
            } else if (news.published) {
                pubDate = new Date(news.published).toLocaleDateString();
            }
            
            // Clean and truncate title
            const title = news.title ? news.title.substring(0, 100) + (news.title.length > 100 ? '...' : '') : 'No title';
            
            // Clean description
            let description = news.description || '';
            if (description) {
                description = description.replace(/<[^>]+>/g, '');
                description = description.length > 120 ? description.substring(0, 120) + '...' : description;
            }
            
            html += `
                <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2">
                    <div class="card h-100 shadow-sm">
                        ${image ? `
                            <img src="${image}" 
                                 class="card-img-top news-image" 
                                 alt="News Image" 
                                 loading="lazy"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                            <div class="bg-light text-center p-3" style="display:none;">
                                <i class="fas fa-image text-muted"></i>
                                <br><small class="text-muted">No image available</small>
                            </div>
                        ` : `
                            <div class="bg-light text-center p-3">
                                <i class="fas fa-newspaper text-muted" style="font-size: 2rem;"></i>
                                <br><small class="text-muted">News Article</small>
                            </div>
                        `}
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">${title}</h5>
                            <p class="card-text flex-grow-1">${description}</p>
                            <div class="mt-auto">
                                <small class="text-muted">${pubDate}</small>
                                <br>
                                <a href="${news.link}" class="btn btn-dark btn-sm mt-2" target="_blank">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += `
                </div>
            </div>
        `;
    });
    
    html += `
            </div>
        </div>
    `;
    
    newsdetails.innerHTML = html;
}

// 🔄 Category Fetch (RSS2JSON fallback) - kept for compatibility
async function fetchGoogleCategory(category) {
    await fetchGoogleRSSWithImages(category);
}

// 🔎 Search Fetch (RSS2JSON fallback)
async function fetchGoogleSearch(query) {
    try {
        const searchRSS = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-GH&gl=GH&ceid=GH:en`;
        const url = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(searchRSS)}`;
        const response = await fetch(url);
        const data = await response.json();
        
        // Enhanced processing for search results too
        const processedItems = data.items ? data.items.map(item => {
            let imageUrl = null;
            
            if (item.enclosure && item.enclosure.link) {
                imageUrl = item.enclosure.link;
            } else if (item.thumbnail) {
                imageUrl = item.thumbnail;
            } else if (item.description) {
                imageUrl = extractImageFromContent(item.description);
            } else if (item.content) {
                imageUrl = extractImageFromContent(item.content);
            }
            
            return {
                ...item,
                image: imageUrl,
                enclosure: imageUrl ? { link: imageUrl } : null
            };
        }) : [];
        
        newsDataArr = processedItems;
        displayNews();
    } catch (error) {
        console.error('Error searching news:', error);
        newsdetails.innerHTML = "<h5>Error searching news. Please try again later.</h5>";
    }
}

// Image preloader function
function preloadImage(src) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(src);
        img.onerror = () => reject();
        img.src = src;
        // Add timeout to prevent hanging
        setTimeout(() => reject(), 5000);
    });
}

// 🖼️ Renderer with Image Support and Preloading
async function displayNews() {
    newsdetails.innerHTML = "";

    if (newsDataArr.length === 0) {
        const alertClass = document.body.classList.contains('dark-mode') ? 'alert alert-info dark-mode' : 'alert alert-info';
        newsdetails.innerHTML = `<div class='col-12'><div class='${alertClass}'><h5>No news found.</h5></div></div>`;
        return;
    }

    // Create all cards first with placeholder images
    const cardPromises = newsDataArr.map(async (news, index) => {
        // Handle different date formats
        let pubDate = "Unknown date";
        if (news.pubDate) {
            pubDate = news.pubDate.split(" ")[0];
        } else if (news.published) {
            pubDate = new Date(news.published).toLocaleDateString();
        }

        const col = document.createElement("div");
        col.className = "col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2";

        const card = document.createElement("div");
        card.className = document.body.classList.contains('dark-mode') ? "card h-100 shadow-sm dark-mode" : "card h-100 shadow-sm";

        // Image handling with multiple fallbacks and preloading
        const image = document.createElement("img");
        image.className = "card-img-top news-image";
        image.setAttribute("alt", news.title);
        
        // Try different image sources with better extraction
        let imageUrl = null;
        
        // Priority order for image sources
        if (news.image && news.image !== "default.jpg" && !news.image.includes("placeholder")) {
            imageUrl = news.image;
        } else if (news.enclosure && news.enclosure.link && news.enclosure.link !== "default.jpg") {
            imageUrl = news.enclosure.link;
        } else if (news.thumbnail && news.thumbnail !== "default.jpg") {
            imageUrl = news.thumbnail;
        } else if (news.description) {
            imageUrl = extractImageFromContent(news.description);
        } else if (news.content) {
            imageUrl = extractImageFromContent(news.content);
        }
        
        // Use centralized image handling utility
        setupImageWithFallbacks(image, imageUrl, news.title);

        const cardBody = document.createElement("div");
        cardBody.className = "card-body d-flex flex-column";

        const newsHeading = document.createElement("h6");
        newsHeading.className = "card-title";
        newsHeading.innerHTML = news.title;

        const dateHeading = document.createElement("small");
        dateHeading.className = "text-primary mb-2";
        dateHeading.innerHTML = pubDate;

        const description = document.createElement("p");
        description.className = "card-text text-muted flex-grow-1";
        // Clean HTML from description
        let cleanDescription = news.description || "No description available.";
        cleanDescription = cleanDescription.replace(/<[^>]*>/g, '');
        description.innerHTML = cleanDescription;

        const link = document.createElement("a");
        link.className = "btn btn-dark btn-sm mt-auto";
        link.setAttribute("target", "_blank");
        link.setAttribute("rel", "noopener noreferrer");
        link.href = news.link;
        link.innerHTML = "Read more";

        cardBody.appendChild(newsHeading);
        cardBody.appendChild(dateHeading);
        cardBody.appendChild(description);
        cardBody.appendChild(link);

        card.appendChild(image);
        card.appendChild(cardBody);
        col.appendChild(card);
        
        return col;
    });

    // Wait for all cards to be ready and append them
    const cards = await Promise.all(cardPromises);
    cards.forEach(card => newsdetails.appendChild(card));
}