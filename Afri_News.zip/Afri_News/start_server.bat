@echo off
echo.
echo =======================================
echo   Ghana-Square News Server
echo =======================================
echo.

REM Activate virtual environment
if exist "venv\Scripts\activate.bat" (
    echo 🔧 Activating virtual environment...
    call venv\Scripts\activate.bat
) else (
    echo 🔧 Creating virtual environment...
    py -m venv venv
    call venv\Scripts\activate.bat
    echo 📦 Installing dependencies...
    pip install -r requirements.txt
)

REM Initialize database if it doesn't exist
if not exist "news.db" (
    echo.
    echo 🗃️ Initializing database...
    python setup.py
)

REM Start the Flask application on port 5001 to avoid conflicts
echo.
echo 🚀 Starting Ghana-Square News Server...
echo.
echo 📡 Server URL: http://localhost:5001
echo 🔍 Health Check: http://localhost:5001/api/health  
echo 📰 Website: Open your index.html file (update port to 5001)
echo.
echo ⚠️  Keep this window open while using the website
echo 🛑 Press Ctrl+C to stop the server
echo.
echo ========================================

set FLASK_PORT=5001
python app.py

if errorlevel 1 (
    echo.
    echo ❌ Server failed to start. Check error above.
    echo.
)

echo.
echo 🛑 Server stopped.
pause