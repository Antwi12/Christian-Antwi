@echo off
echo.
echo =======================================
echo   PYTHON DIAGNOSTIC TOOL
echo =======================================
echo.

cd /d "c:\xampp\htdocs\Afri_News"

echo 🔍 Testing Python commands...
echo.

echo Testing 'py' command:
py --version 2>&1
echo Error level: %errorlevel%
echo.

echo Testing 'python' command:
python --version 2>&1
echo Error level: %errorlevel%
echo.

echo Testing 'python3' command:
python3 --version 2>&1
echo Error level: %errorlevel%
echo.

echo 🔍 Testing venv capability...
echo.

echo Testing 'py -m venv':
py -m venv --help 2>&1 | findstr "usage"
echo Error level: %errorlevel%
echo.

echo Testing 'python -m venv':
python -m venv --help 2>&1 | findstr "usage"
echo Error level: %errorlevel%
echo.

echo 🔍 Testing pip capability...
echo.

echo Testing 'py -m pip':
py -m pip --version 2>&1
echo Error level: %errorlevel%
echo.

echo Testing 'python -m pip':
python -m pip --version 2>&1
echo Error level: %errorlevel%
echo.

echo 🔍 Current directory contents:
dir
echo.

echo 🔍 PATH variable:
echo %PATH%
echo.

echo =======================================
echo   DIAGNOSTIC COMPLETE
echo =======================================
echo.
echo Based on the results above, try:
echo 1. SIMPLE_START.bat (no virtual environment)
echo 2. ULTIMATE_FIX.bat (handles venv issues)
echo.
pause