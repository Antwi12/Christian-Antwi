@echo off
echo.
echo =======================================
echo   FIXED - Ghana-Square News Server
echo =======================================
echo.

cd /d "c:\xampp\htdocs\Afri_News"

REM Kill any process using port 5000 or 5001
echo 🔧 Checking for running servers...
netstat -ano | findstr ":5000" > nul 2>&1
if not errorlevel 1 (
    echo ⚠️  Port 5000 is in use, switching to 5001
)

REM Activate or create virtual environment
if not exist "venv\Scripts\activate.bat" (
    echo 🔧 Creating virtual environment...
    py -m venv venv
    if errorlevel 1 (
        echo ❌ Failed to create virtual environment
        pause
        exit /b 1
    )
)

echo 🔧 Activating virtual environment...
call venv\Scripts\activate.bat

REM Install dependencies
echo 📦 Installing/updating dependencies...
pip install --upgrade pip
pip install -r requirements.txt

if errorlevel 1 (
    echo ❌ Failed to install dependencies
    pause
    exit /b 1
)

REM Initialize database
if not exist "news.db" (
    echo 🗃️ Initializing database...
    python setup.py
)

REM Start server on port 5001
echo.
echo 🚀 Starting Ghana-Square News Server on port 5001...
echo.
echo 📡 Server URL: http://localhost:5001
echo 🔍 Health Check: http://localhost:5001/api/health
echo 📰 Website: Open your index.html file in browser
echo.
echo ⚠️  Keep this window open while using the website
echo 🛑 Press Ctrl+C to stop the server
echo.
echo ========================================

set FLASK_PORT=5001
python app.py

echo.
echo 🛑 Server stopped.
pause