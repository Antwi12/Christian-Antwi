#!/bin/bash

echo ""
echo "======================================="
echo "   Ghana-Square News Server Startup"
echo "======================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    echo "Please install Python 3.7+ and try again"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "Error: Failed to create virtual environment"
        exit 1
    fi
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install dependencies if requirements.txt exists
if [ -f "requirements.txt" ]; then
    echo "Installing/updating dependencies..."
    pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "Warning: Some dependencies might not have installed correctly"
    fi
fi

# Run setup script if database doesn't exist
if [ ! -f "news.db" ]; then
    echo "Running initial setup..."
    python setup.py
fi

# Start the Flask application
echo ""
echo "Starting Flask application..."
echo "Server will be available at: http://localhost:5000"
echo "API Health Check: http://localhost:5000/api/health"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

python app.py

echo ""
echo "Server stopped."