@echo off
echo.
echo ========================================
echo   Ghana-Square News System Test
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    pause
    exit /b 1
)

REM Check if Flask server is running
echo Checking if Flask server is running...
python -c "import requests; requests.get('http://localhost:5000/api/health', timeout=2)" >nul 2>&1
if errorlevel 1 (
    echo.
    echo ❌ Flask server is not running!
    echo Please start the server first by running: start_server.bat
    echo.
    pause
    exit /b 1
)

echo ✅ Flask server is running!
echo.
echo Running comprehensive tests...
echo.

REM Run the test script
python test_system.py

echo.
echo Test completed! Check the results above.
echo.
pause