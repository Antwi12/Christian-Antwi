@echo off
echo Testing Flask directly...
echo.

py -c "import flask; print('Flask version:', flask.__version__)"
if errorlevel 1 (
    echo Flask import failed
    pause
    exit /b 1
)

echo Flask import successful!
echo.

echo Testing Flask app creation...
py -c "from flask import Flask; app = Flask(__name__); print('Flask app created successfully!')"
if errorlevel 1 (
    echo Flask app creation failed
    pause
    exit /b 1
)

echo Flask app creation successful!
echo.

echo Now trying to run setup.py...
py setup.py

echo.
echo Now trying to run app.py...
py app.py

pause