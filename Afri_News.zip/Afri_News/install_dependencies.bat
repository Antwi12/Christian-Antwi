@echo off
echo.
echo =======================================
echo   Ghana-Square News - Install Dependencies
echo =======================================
echo.

REM Find Python
set PYTHON_CMD=

py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    goto :install_deps
)

python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    goto :install_deps
)

python3 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python3
    goto :install_deps
)

echo Error: Python not found!
echo Please install Python from https://python.org
echo Make sure to check "Add Python to PATH" during installation
pause
exit /b 1

:install_deps
echo Found Python: %PYTHON_CMD%
%PYTHON_CMD% --version

REM Upgrade pip
echo.
echo Upgrading pip...
%PYTHON_CMD% -m pip install --upgrade pip

REM Install core dependencies first
echo.
echo Installing core dependencies...
%PYTHON_CMD% -m pip install Flask Flask-CORS requests beautifulsoup4

REM Install additional dependencies
echo.
echo Installing additional dependencies...
%PYTHON_CMD% -m pip install feedparser APScheduler dicttoxml python-dateutil

REM Verify installation with better error handling
echo.
echo Verifying installation...

%PYTHON_CMD% -c "import flask; print('Flask version:', flask.__version__)" 2>nul
if errorlevel 1 (
    echo.
    echo Error verifying Flask. Trying to install again...
    %PYTHON_CMD% -m pip install --force-reinstall Flask
    %PYTHON_CMD% -c "import flask; print('Flask version:', flask.__version__)" 2>nul
    if errorlevel 1 (
        echo Flask installation failed. Please check your Python installation.
        pause
        exit /b 1
    )
)

echo Flask installed successfully!

REM Test other imports
%PYTHON_CMD% -c "import requests, feedparser, bs4; print('All core dependencies working!')" 2>nul
if errorlevel 1 (
    echo Warning: Some dependencies may not be fully installed
    echo The server should still work for basic functionality
)

REM Run initial setup
echo.
echo Setting up database...
%PYTHON_CMD% setup.py

echo.
echo ========================================
echo Installation completed successfully!
echo.
echo Next steps:
echo 1. Double-click start_server.bat to start the server
echo 2. Open index.html in your browser
echo 3. Enjoy your Ghana-Square News website!
echo ========================================
echo.
pause