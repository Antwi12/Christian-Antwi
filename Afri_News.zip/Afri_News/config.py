import requests

# Define API keys
NEWS_API_KEY = 'd7aa6be0e6a94cce9b9d6c72e8e94be4'
GNEWS_API_KEY = 'ab862b79766e9bc25438dc2849a6f6fd'

# Define endpoints
NEWS_API_URL = 'https://newsapi.org/v2/everything'
GNEWS_API_URL = 'https://gnews.io/api/v4/search'


def fetch_newsapi(query):
    params = {
        'q': query,
        'apiKey': NEWS_API_KEY,
        'language': 'en'
    }
    response = requests.get(NEWS_API_URL, params=params)
    return response.json()['articles']

def fetch_gnews(query):
    params = {
        'q': query,
        'token': GNEWS_API_KEY,
        'lang': 'en'
    }
    response = requests.get(GNEWS_API_URL, params=params)
    return response.json()['articles']
import feedparser

def fetch_google_news(query):
    url = f'https://news.google.com/rss/search?q={query}'
    feed = feedparser.parse(url)
    return feed.entries

def fetch_yahoo_news(query):
    url = f'https://news.yahoo.com/rss/search?p={query}'
    feed = feedparser.parse(url)
    return feed.entries

def get_all_news(query):
    news_data = {
        'NewsAPI': fetch_newsapi(query),
        'GNews': fetch_gnews(query),
        'GoogleNews': fetch_google_news(query),
        'YahooNews': fetch_yahoo_news(query)
    }
    return news_data

