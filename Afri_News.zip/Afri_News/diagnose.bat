@echo off
echo.
echo =======================================
echo   Python & Flask Diagnostics
echo =======================================
echo.

echo 1. Testing Python commands:
echo.

echo Testing 'py' command:
py --version 2>nul
if errorlevel 1 (
    echo   py: NOT WORKING
) else (
    echo   py: WORKING
    py --version
)

echo.
echo Testing 'python' command:
python --version 2>nul
if errorlevel 1 (
    echo   python: NOT WORKING
) else (
    echo   python: WORKING
    python --version
)

echo.
echo Testing 'python3' command:
python3 --version 2>nul
if errorlevel 1 (
    echo   python3: NOT WORKING
) else (
    echo   python3: WORKING
    python3 --version
)

echo.
echo =======================================
echo 2. Testing Flask with different commands:
echo =======================================
echo.

echo Testing Flask with 'py':
py -c "import flask; print('Flask version with py:', flask.__version__)" 2>nul
if errorlevel 1 (
    echo   Flask with 'py': FAILED
) else (
    echo   Flask with 'py': SUCCESS
)

echo.
echo Testing Flask with 'python':
python -c "import flask; print('Flask version with python:', flask.__version__)" 2>nul
if errorlevel 1 (
    echo   Flask with 'python': FAILED
) else (
    echo   Flask with 'python': SUCCESS
)

echo.
echo Testing Flask with 'python3':
python3 -c "import flask; print('Flask version with python3:', flask.__version__)" 2>nul
if errorlevel 1 (
    echo   Flask with 'python3': FAILED
) else (
    echo   Flask with 'python3': SUCCESS
)

echo.
echo =======================================
echo 3. Python installation details:
echo =======================================
echo.

echo Python executable locations:
where py 2>nul
where python 2>nul
where python3 2>nul

echo.
echo Python site-packages location:
py -c "import site; print('Site packages:', site.getsitepackages())" 2>nul

echo.
echo Installed packages:
py -m pip list | findstr -i flask 2>nul

echo.
echo =======================================
echo 4. Trying to fix the issue:
echo =======================================
echo.

echo Attempting to install Flask directly to current Python:
py -m pip install --force-reinstall flask

echo.
echo Testing after reinstall:
py -c "import flask; print('SUCCESS: Flask is now working!'); print('Version:', flask.__version__)"

if errorlevel 1 (
    echo.
    echo =======================================
    echo DIAGNOSIS COMPLETE - ISSUE FOUND
    echo =======================================
    echo.
    echo There appears to be a Python environment issue.
    echo Please try these solutions:
    echo.
    echo 1. Restart Command Prompt as Administrator
    echo 2. Try: py -m pip install --user flask
    echo 3. Or reinstall Python from python.org
    echo.
) else (
    echo.
    echo =======================================
    echo SUCCESS! Flask is now working!
    echo =======================================
    echo.
    echo You can now run: start_server.bat
    echo.
)

pause