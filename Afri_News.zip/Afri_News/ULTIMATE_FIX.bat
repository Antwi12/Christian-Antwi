@echo off
echo.
echo =======================================
echo   ULTIMATE FIX - Ghana-Square News Server
echo =======================================
echo.

cd /d "c:\xampp\htdocs\Afri_News"

REM Test Python installation
echo 🔍 Testing Python installation...
py --version
if errorlevel 1 (
    echo ❌ Python 'py' command failed
    python --version
    if errorlevel 1 (
        echo ❌ Python not found or not in PATH
        echo.
        echo Please install Python from: https://python.org
        echo Make sure to check "Add Python to PATH" during installation
        pause
        exit /b 1
    ) else (
        set PYTHON_CMD=python
    )
) else (
    set PYTHON_CMD=py
)

echo ✅ Python found: %PYTHON_CMD%

REM Test if we can create venv
echo 🔍 Testing virtual environment capability...
%PYTHON_CMD% -m venv --help >nul 2>&1
if errorlevel 1 (
    echo ❌ Virtual environment module not available
    echo Installing without virtual environment...
    goto :no_venv
)

REM Remove existing broken venv if exists
if exist "venv" (
    echo 🧹 Removing existing virtual environment...
    rmdir /s /q "venv" 2>nul
)

REM Try to create virtual environment
echo 🔧 Creating fresh virtual environment...
%PYTHON_CMD% -m venv venv --clear
if errorlevel 1 (
    echo ❌ Virtual environment creation failed
    echo Trying alternative method...
    goto :no_venv
)

echo ✅ Virtual environment created successfully
call venv\Scripts\activate.bat
goto :install_deps

:no_venv
echo ⚠️  Installing dependencies globally (no virtual environment)
set PYTHON_CMD=%PYTHON_CMD%

:install_deps
echo 📦 Installing dependencies...
%PYTHON_CMD% -m pip install --upgrade pip
%PYTHON_CMD% -m pip install Flask>=2.3.0
%PYTHON_CMD% -m pip install Flask-CORS>=4.0.0
%PYTHON_CMD% -m pip install feedparser>=6.0.0
%PYTHON_CMD% -m pip install requests>=2.31.0
%PYTHON_CMD% -m pip install APScheduler>=3.10.0
%PYTHON_CMD% -m pip install dicttoxml>=1.7.0
%PYTHON_CMD% -m pip install beautifulsoup4>=4.12.0
%PYTHON_CMD% -m pip install python-dateutil>=2.8.0

if errorlevel 1 (
    echo ❌ Failed to install some dependencies
    echo Trying to continue anyway...
)

REM Test Flask import
echo 🔍 Testing Flask installation...
%PYTHON_CMD% -c "import flask; print('✅ Flask version:', flask.__version__)"
if errorlevel 1 (
    echo ❌ Flask import failed
    echo.
    echo Possible solutions:
    echo 1. Restart this script as Administrator
    echo 2. Check your Python installation
    echo 3. Try installing Python from Microsoft Store
    pause
    exit /b 1
)

REM Initialize database
if not exist "news.db" (
    echo 🗃️ Initializing database...
    %PYTHON_CMD% setup.py
)

REM Start server
echo.
echo 🚀 Starting Ghana-Square News Server...
echo.
echo 📡 Server URL: http://localhost:5001
echo 🔍 Health Check: http://localhost:5001/api/health
echo 📰 Website: Open your index.html file in browser
echo.
echo ⚠️  Keep this window open while using the website
echo 🛑 Press Ctrl+C to stop the server
echo.
echo ========================================

set FLASK_PORT=5001
%PYTHON_CMD% app.py

if errorlevel 1 (
    echo.
    echo ❌ Server failed to start
    echo.
    echo Debugging information:
    %PYTHON_CMD% -c "
import sys
print('Python executable:', sys.executable)
print('Python version:', sys.version)
try:
    import flask
    print('Flask imported successfully')
    print('Flask version:', flask.__version__)
except Exception as e:
    print('Flask import error:', e)
"
    echo.
)

echo.
echo 🛑 Server stopped.
pause