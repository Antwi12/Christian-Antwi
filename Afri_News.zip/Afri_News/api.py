from flask import Flask, request, Response
from app.fetcher import get_news
from app.storage import save_to_xml
import dicttoxml

app = Flask(__name__)

@app.route('/getnews', methods=['GET'])
def getnews():
    topic = request.args.get('topic')
    results = get_news(topic)
    xml = dicttoxml.dicttoxml(results)
    save_to_xml(results)
    return Response(xml, mimetype='application/xml')

if __name__ == '__main__':
    app.run(debug=True)
