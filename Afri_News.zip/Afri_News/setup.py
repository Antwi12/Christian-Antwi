#!/usr/bin/env python3
"""
Ghana-Square News Setup Script
This script sets up the database and initializes the Flask application
"""

import sqlite3
import os
import sys
import subprocess

def install_dependencies():
    """Install required Python packages"""
    print("Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing dependencies: {e}")
        return False

def setup_database():
    """Initialize the database with required tables"""
    print("Setting up database...")
    try:
        conn = sqlite3.connect('news.db')
        cursor = conn.cursor()
        
        # Create news_articles table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS news_articles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                content TEXT,
                url TEXT UNIQUE NOT NULL,
                image_url TEXT,
                source TEXT,
                category TEXT,
                location TEXT,
                published_at DATETIME,
                fetched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                hash TEXT UNIQUE
            )
        ''')
        
        # Create fetch_logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fetch_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT,
                source TEXT,
                articles_count INTEGER,
                fetched_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create indexes for better performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_category ON news_articles(category)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_location ON news_articles(location)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_published ON news_articles(published_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_fetched ON news_articles(fetched_at)')
        
        conn.commit()
        conn.close()
        print("✅ Database setup completed!")
        return True
    except Exception as e:
        print(f"❌ Error setting up database: {e}")
        return False

def create_config_file():
    """Create a configuration file for API keys"""
    config_content = """# Ghana-Square News Configuration
# Replace the placeholder values with your actual API keys

# NewsAPI (https://newsapi.org/)
NEWSAPI_KEY=your_newsapi_key_here

# GNews API (https://gnews.io/)
GNEWS_KEY=your_gnews_key_here

# Flask Configuration
FLASK_DEBUG=True
FLASK_HOST=0.0.0.0
FLASK_PORT=5000

# Database Configuration
DATABASE_NAME=news.db

# Cron Job Configuration (in minutes)
FETCH_INTERVAL=30
DEFAULT_TOPICS=Ghana,Kumasi,Accra,Cape Coast
DEFAULT_CATEGORIES=business,sports,technology,entertainment
"""
    
    if not os.path.exists('config.env'):
        with open('config.env', 'w') as f:
            f.write(config_content)
        print("✅ Configuration file created: config.env")
        print("📝 Please edit config.env and add your API keys")
    else:
        print("ℹ️  Configuration file already exists: config.env")

def main():
    """Main setup function"""
    print("🚀 Ghana-Square News Setup")
    print("=" * 40)
    
    # Install dependencies
    if not install_dependencies():
        print("❌ Setup failed during dependency installation")
        return False
    
    # Setup database
    if not setup_database():
        print("❌ Setup failed during database setup")
        return False
    
    # Create config file
    create_config_file()
    
    print("\n✅ Setup completed successfully!")
    print("\n📋 Next steps:")
    print("1. Edit config.env and add your API keys")
    print("2. Run: python app.py")
    print("3. Open your browser and go to: http://localhost:5000/api/health")
    print("4. Open index.html in your browser to use the news website")
    
    return True

if __name__ == "__main__":
    main()