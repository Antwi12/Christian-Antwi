import requests
from app.config import NEWS_API_URL, NEWS_API_KEY 

def get_news(topic):
    params = {
        'q': topic,
        'apiKey': NEWS_API_KEY,
        'language': 'en',
        'pageSize': 10
    }
    response = requests.get(NEWS_API_URL, params=params)
    return response.json().get('articles', [])
