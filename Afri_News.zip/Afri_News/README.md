# 🇬🇭 Ghana-Square News

A comprehensive news aggregation website that fetches news from multiple sources including Yahoo News, Google News, NewsAPI, and GNews. Features categorized search, automated news fetching with cron jobs, and database storage with duplicate prevention.

## ✨ Features

### 🔍 **Smart Search System**
- **Regular Search**: Search for any topic across all news sources
- **Categorized Search**: Search by location (e.g., "Kumasi") and get results organized by:
  - Business
  - Sports  
  - Technology
  - Entertainment

### 📱 **Responsive Design**
- Mobile-friendly interface
- Dark mode toggle
- Bootstrap-powered UI
- Currency converter modal

### 🔄 **Automated News Fetching**
- Cron job system for automatic news updates
- Configurable fetch intervals (default: 30 minutes)
- Duplicate article prevention
- Database storage with full logging

### 🌐 **Multiple News Sources**
- Yahoo News RSS
- Google News RSS
- NewsAPI.org
- GNews.io
- RSS2JSON fallback for enhanced compatibility

### 📊 **Database Integration**
- SQLite database for article storage
- Automatic duplicate detection using content hashing
- Full-text search capabilities
- Fetch logging and analytics

## 🚀 Quick Start

### Windows Users
1. **Clone/Download** this repository to `c:\xampp\htdocs\Afri_News`
2. **Double-click** `start_server.bat`
3. **Open** your browser and go to `http://localhost:5000/api/health`
4. **Open** `index.html` in your browser to use the website

### Linux/Mac Users
1. **Clone/Download** this repository
2. **Make executable**: `chmod +x start_server.sh`
3. **Run**: `./start_server.sh`
4. **Open** your browser and go to `http://localhost:5000/api/health`
5. **Open** `index.html` in your browser to use the website

### Manual Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Run setup script
python setup.py

# Start the Flask server
python app.py
```

## 🔧 Configuration

### API Keys Setup
Edit the `config.env` file (created after first run) and add your API keys:

```env
# NewsAPI (https://newsapi.org/)
NEWSAPI_KEY=your_actual_newsapi_key

# GNews API (https://gnews.io/)
GNEWS_KEY=your_actual_gnews_key
```

### Getting API Keys
1. **NewsAPI**: Register at [newsapi.org](https://newsapi.org/)
2. **GNews**: Register at [gnews.io](https://gnews.io/)

*Note: The system works without API keys using RSS feeds as fallback*

## 📡 API Endpoints

### Core News Endpoints
- `GET /api/health` - Health check
- `GET /api/news` - Get general news from Yahoo RSS
- `GET /api/google-news/<category>` - Get news by category
- `GET /api/search/<query>` - Search news

### Categorized Search
- `GET /api/categorized-search/<location>` - Get categorized news by location

### Database Endpoints
- `GET /api/database/articles` - Get stored articles
  - Query params: `category`, `location`, `limit`

### XML API (Query String Based)
- `GET /getnews?topic=<topic>&category=<category>&location=<location>&format=<xml|json>`

### Cron Job Management
- `GET /api/cron/start` - Start automated news fetching
- `GET /api/cron/stop` - Stop automated news fetching  
- `GET /api/cron/status` - Get cron job status

## 💻 Usage Examples

### Regular Search
1. Enter search term (e.g., "Ghana politics")
2. Click Search
3. View results in card layout

### Categorized Search
1. Check "Categorized" checkbox
2. Enter location (e.g., "Kumasi")
3. Click Search
4. View results organized in tabs by category

### API Usage Examples

```bash
# Get general news
curl "http://localhost:5000/api/news"

# Search for news
curl "http://localhost:5000/api/search/Kumasi"

# Get categorized search results
curl "http://localhost:5000/api/categorized-search/Accra"

# Get XML results with query parameters
curl "http://localhost:5000/getnews?topic=Ghana&category=sports&format=xml"

# Start automatic news fetching
curl "http://localhost:5000/api/cron/start"
```

### Frontend Features
- **Dark Mode**: Click the 🌓 button in top-right
- **Currency Converter**: Click 💱 Currency button in navbar
- **Responsive**: Works on desktop, tablet, and mobile
- **Image Loading**: Automatic image extraction and error handling

## 🗄️ Database Schema

### news_articles
```sql
- id (PRIMARY KEY)
- title (TEXT)
- description (TEXT)
- content (TEXT)
- url (TEXT UNIQUE)
- image_url (TEXT)
- source (TEXT)
- category (TEXT)
- location (TEXT)
- published_at (DATETIME)
- fetched_at (DATETIME)
- hash (TEXT UNIQUE) -- for duplicate prevention
```

### fetch_logs
```sql
- id (PRIMARY KEY)
- query (TEXT)
- source (TEXT)
- articles_count (INTEGER)
- fetched_at (DATETIME)
```

## 🔧 Troubleshooting

### Common Issues

**1. Flask server won't start**
```bash
# Check if port 5000 is in use
netstat -an | find "5000"

# Use different port
python app.py --port 5001
```

**2. Console errors about images (FIXED)**
- ✅ **Fixed in latest version**: No more `via.placeholder.com` errors
- ✅ **New system**: Uses inline SVG placeholders that never fail
- ✅ **Test page**: Open `test_images.html` to verify image handling
- All tabs now use consistent image fallback system

**3. No images loading**
- Images are extracted from RSS feeds using enhanced extraction
- Some sources may not provide images (normal behavior)
- System shows appropriate placeholders for missing images
- Check browser console (F12) for image extraction logs

**4. API keys not working**
- Verify keys in `config.env` 
- Check API quotas/limits
- RSS fallback will still work

**5. Database issues**
```bash
# Reset database
rm news.db
python setup.py
```

### Performance Tips
1. **Enable cron jobs** for automatic updates
2. **Use categorized search** for better results
3. **Clear old articles** periodically from database
4. **Monitor API quotas** to avoid rate limiting

## 📁 Project Structure

```
Afri_News/
├── app.py                 # Main Flask application
├── yahoo.py              # Yahoo News specific handlers
├── index.html            # Frontend HTML
├── index.js              # Frontend JavaScript
├── style.css             # Styling
├── setup.py              # Database setup script
├── requirements.txt      # Python dependencies
├── start_server.bat      # Windows startup script
├── start_server.sh       # Linux/Mac startup script
├── config.env            # Configuration file (created on first run)
├── news.db              # SQLite database (created on first run)
└── images/              # Static images
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## 📄 License

This project is open source and available under the MIT License.

## 🆘 Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Look at the console/terminal for error messages
3. Ensure all dependencies are installed
4. Verify API keys are correct (if using paid APIs)

---

**Happy News Reading!** 📰🇬🇭