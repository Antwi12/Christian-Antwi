import os
os.system('pip install newsdataapi')

from newsdataapi import NewsDataApiClient

# 🔑 Replace with your actual API key from https://newsdata.io/
api = NewsDataApiClient(apikey='pub_5acc0e3c564d44a2a2aa37b8e0bb26ba')

# 🔍 Search for news articles (customize query, category, country, language)
response = api.news_api(
    q='technology',                # Keyword to search
    category='technology',         # Category: sports, business, entertainment, etc.
    country='gh',                  # Country code (e.g., 'gh' for Ghana)
    language='en',                 # Language code
    page=1                         # Pagination
)

# 📰 Display results
for article in response['results']:
    print(f"Title: {article['title']}")
    print(f"Source: {article['source_id']}")
    print(f"Published: {article['pubDate']}")
    print(f"Link: {article['link']}")
    print("-" * 50)
