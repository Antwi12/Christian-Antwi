@echo off
echo.
echo =======================================
echo   Force Starting Server (Bypass Import Issues)
echo =======================================
echo.

echo Flask IS installed - forcing direct server start...
echo.

REM Set Python path explicitly
set PYTHONPATH=C:\Users\user\AppData\Local\Programs\Python\Python313\Lib\site-packages;%PYTHONPATH%

echo Setting up database first...
py setup.py

if errorlevel 1 (
    echo Database setup had issues, but continuing...
)

echo.
echo =======================================
echo Starting server directly...
echo =======================================
echo.
echo If Flask import errors appear, they'll show here:
echo.

py app.py

if errorlevel 1 (
    echo.
    echo Server start failed. Let's see the actual error:
    echo.
    py -c "
import sys
print('Python version:', sys.version)
print('Python path:')
for p in sys.path:
    print('  ', p)
print()
try:
    import flask
    print('SUCCESS: Flask imported!')
    print('Flask location:', flask.__file__)
    print('Flask version:', flask.__version__)
except ImportError as e:
    print('IMPORT ERROR:', e)
    print()
    print('Checking site-packages contents:')
    import os
    site_pkg = r'C:\Users\user\AppData\Local\Programs\Python\Python313\Lib\site-packages'
    if os.path.exists(site_pkg):
        items = [item for item in os.listdir(site_pkg) if 'flask' in item.lower()]
        print('Flask-related items in site-packages:')
        for item in items:
            print('  ', item)
    else:
        print('Site-packages directory not found!')
"
)

echo.
pause