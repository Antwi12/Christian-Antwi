@echo off
echo.
echo =======================================
echo   SIMPLE START - Ghana-Square News Server
echo =======================================
echo.

cd /d "c:\xampp\htdocs\Afri_News"

REM Find Python
echo 🔍 Finding Python...
py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    echo ✅ Found: py
) else (
    python --version >nul 2>&1
    if not errorlevel 1 (
        set PYTHON_CMD=python
        echo ✅ Found: python
    ) else (
        echo ❌ Python not found!
        echo Please install Python from https://python.org
        pause
        exit /b 1
    )
)

REM Install dependencies directly (no virtual environment)
echo 📦 Installing Flask and dependencies...
%PYTHON_CMD% -m pip install Flask Flask-CORS feedparser requests APScheduler dicttoxml beautifulsoup4 python-dateutil

REM Test Flask
echo 🔍 Testing Flask...
%PYTHON_CMD% -c "import flask; print('Flask OK:', flask.__version__)"
if errorlevel 1 (
    echo ❌ Flask test failed
    pause
    exit /b 1
)

REM Initialize database
if not exist "news.db" (
    echo 🗃️ Creating database...
    %PYTHON_CMD% setup.py
)

REM Kill any process on port 5001
echo 🔧 Checking port 5001...
netstat -ano | findstr ":5001" >nul 2>&1
if not errorlevel 1 (
    echo ⚠️  Port 5001 in use, trying to continue anyway...
)

REM Start server
echo.
echo 🚀 Starting server on port 5001...
echo.
echo 📡 Open: http://localhost:5001/api/health
echo 📰 Then open: index.html in your browser
echo.
echo ⚠️  Keep this window open!
echo 🛑 Press Ctrl+C to stop
echo.

set FLASK_PORT=5001
%PYTHON_CMD% app.py

echo.
echo 🛑 Server stopped.
pause