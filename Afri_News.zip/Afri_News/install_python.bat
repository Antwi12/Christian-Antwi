@echo off
echo ======================================
echo   Python Installation Helper
echo ======================================
echo.

REM Method 1: Try winget (Windows Package Manager)
echo [1/4] Trying Windows Package Manager (winget)...
winget install Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements >nul 2>&1
if not errorlevel 1 (
    echo ✅ Python installed via winget!
    goto :verify
)

REM Method 2: Try chocolatey
echo [2/4] Trying Chocolatey...
choco install python -y >nul 2>&1
if not errorlevel 1 (
    echo ✅ Python installed via Chocolatey!
    goto :verify
)

REM Method 3: Try Microsoft Store
echo [3/4] Trying Microsoft Store Python...
start ms-windows-store://pdp/?ProductId=9NCVDN91XZQP
echo.
echo ⏳ Microsoft Store opened. Please:
echo    1. Click "Install" for Python 3.12
echo    2. Wait for installation to complete
echo    3. Close the store and press any key here
pause

REM Method 4: Manual download
echo [4/4] Manual download method...
echo.
echo ❌ Automatic installation failed.
echo.
echo 📋 Manual Steps:
echo 1. Go to: https://www.python.org/downloads/windows/
echo 2. Download: python-3.12.x-amd64.exe
echo 3. Run as Administrator
echo 4. ✅ CHECK "Add Python to PATH"
echo 5. Click "Install Now"
echo.
echo Press any key after manual installation...
pause

:verify
echo.
echo 🔍 Verifying Python installation...
python --version
if errorlevel 1 (
    echo.
    echo ❌ Python verification failed.
    echo Please restart your computer and try again.
    pause
    exit /b 1
)

echo.
echo ✅ Python installed successfully!
echo.
echo 📦 Installing Flask dependencies...
python -m pip install --upgrade pip
python -m pip install Flask Flask-CORS feedparser requests APScheduler dicttoxml beautifulsoup4 python-dateutil

echo.
echo ✅ Setup complete! 
echo Now you can run: start_server.bat
pause