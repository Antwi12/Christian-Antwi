@echo off
echo =======================================
echo   BBC NEWS INTEGRATION - SERVER START
echo =======================================
echo.

echo [1/2] Stopping any existing Python processes...
taskkill /f /im python.exe >nul 2>&1

echo [2/2] Starting Flask server with complete BBC integration...
echo.
echo ✅ BBC CATEGORY FEEDS READY!
echo    📈 Business  ⚽ Sports  💻 Technology  🎭 Entertainment
echo.
echo ✅ BBC SEARCH SYSTEM ACTIVE!
echo    🔍 8 BBC RSS feeds with smart relevance scoring
echo.
echo ✅ BBC PLACEHOLDERS LOADED!
echo    🎨 Professional gradients, no external dependencies
echo.
echo 🌐 Server will start on: http://127.0.0.1:5001
echo.
echo 🧪 TEST YOUR BBC INTEGRATION:
echo    • Open: index.html (main website)
echo    • Open: BBC_SEARCH_TEST.html (search testing)
echo    • Open: BBC_TEST.html (placeholder demo)
echo.

cd /d "c:\xampp\htdocs\Afri_News"
python app.py
pause