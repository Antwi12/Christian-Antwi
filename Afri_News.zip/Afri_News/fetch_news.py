from app.fetcher import get_news
from app.storage import save_to_xml, save_to_db

TOPICS = ['technology', 'health']

for topic in TOPICS:
    articles = get_news(topic)
    for a in articles:
        a['topic'] = topic  # Tag with topic
    save_to_xml(articles)
    save_to_db(articles)
