#!/usr/bin/env python3
"""
Test script for Ghana-Square News system
This script tests all the main functionality
"""

import requests
import json
import time
import sys
from datetime import datetime

BASE_URL = "http://localhost:5000"

def test_health_check():
    """Test if the Flask server is running"""
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print("✅ Health check passed")
            print(f"   Status: {data.get('status')}")
            return True
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        return False

def test_general_news():
    """Test general news endpoint"""
    try:
        print("\n🔍 Testing general news...")
        response = requests.get(f"{BASE_URL}/api/news", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ General news: {len(data)} articles fetched")
            if data and len(data) > 0:
                print(f"   Sample title: {data[0].get('title', 'No title')[:50]}...")
            return True
    except Exception as e:
        print(f"❌ General news test failed: {e}")
        return False

def test_category_news():
    """Test category news endpoints"""
    categories = ['business', 'sports', 'technology', 'entertainment']
    for category in categories:
        try:
            print(f"\n🏷️  Testing {category} news...")
            response = requests.get(f"{BASE_URL}/api/google-news/{category}", timeout=10)
            if response.status_code == 200:
                data = response.json()
                print(f"✅ {category.title()} news: {len(data)} articles fetched")
                if data and len(data) > 0:
                    print(f"   Sample title: {data[0].get('title', 'No title')[:50]}...")
            else:
                print(f"⚠️  {category.title()} news: No data returned")
        except Exception as e:
            print(f"❌ {category.title()} news test failed: {e}")

def test_search():
    """Test search functionality"""
    search_queries = ['Ghana', 'Kumasi', 'Accra']
    for query in search_queries:
        try:
            print(f"\n🔍 Testing search for '{query}'...")
            response = requests.get(f"{BASE_URL}/api/search/{query}", timeout=10)
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Search '{query}': {len(data)} articles found")
                if data and len(data) > 0:
                    print(f"   Sample title: {data[0].get('title', 'No title')[:50]}...")
            else:
                print(f"⚠️  Search '{query}': No data returned")
        except Exception as e:
            print(f"❌ Search '{query}' test failed: {e}")

def test_categorized_search():
    """Test categorized search functionality"""
    try:
        print(f"\n🗂️  Testing categorized search for 'Kumasi'...")
        response = requests.get(f"{BASE_URL}/api/categorized-search/Kumasi", timeout=15)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Categorized search: Found categories:")
            for category, articles in data.items():
                print(f"   - {category.title()}: {len(articles)} articles")
        else:
            print(f"⚠️  Categorized search: No data returned")
    except Exception as e:
        print(f"❌ Categorized search test failed: {e}")

def test_xml_api():
    """Test XML API endpoint"""
    try:
        print(f"\n📄 Testing XML API...")
        response = requests.get(f"{BASE_URL}/getnews?topic=Ghana&format=xml", timeout=10)
        if response.status_code == 200:
            print(f"✅ XML API: Response received ({len(response.content)} bytes)")
            if response.headers.get('content-type', '').startswith('application/xml'):
                print("   Content-Type: application/xml ✓")
            else:
                print(f"   Content-Type: {response.headers.get('content-type', 'unknown')}")
        else:
            print(f"⚠️  XML API: Status code {response.status_code}")
    except Exception as e:
        print(f"❌ XML API test failed: {e}")

def test_cron_status():
    """Test cron job status"""
    try:
        print(f"\n⏰ Testing cron job status...")
        response = requests.get(f"{BASE_URL}/api/cron/status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Cron status: Running={data.get('running')}, Jobs={data.get('jobs')}")
        else:
            print(f"⚠️  Cron status: Status code {response.status_code}")
    except Exception as e:
        print(f"❌ Cron status test failed: {e}")

def test_currency_converter():
    """Test currency converter API endpoints"""
    try:
        print(f"\n💱 Testing currency converter API...")
        
        # Test currency conversion
        response = requests.get(f"{BASE_URL}/api/currency/convert?amount=100&from_currency=USD&to_currency=GHS", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Currency conversion: {data.get('amount')} {data.get('from_currency')} = {data.get('converted_amount')} {data.get('to_currency')}")
            print(f"   Exchange rate: {data.get('exchange_rate')}, Source: {data.get('source')}")
        else:
            print(f"⚠️  Currency conversion: Status code {response.status_code}")
        
        # Test supported currencies
        response = requests.get(f"{BASE_URL}/api/currency/supported", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Supported currencies: {data.get('count')} currencies available")
        else:
            print(f"⚠️  Supported currencies: Status code {response.status_code}")
        
        # Test exchange rates
        response = requests.get(f"{BASE_URL}/api/currency/rates/USD", timeout=10)
        if response.status_code == 200:
            data = response.json()
            rates = data.get('rates', {})
            print(f"✅ Exchange rates: {len(rates)} rates for {data.get('base_currency')}")
            if 'GHS' in rates:
                print(f"   USD to GHS: {rates['GHS']}")
        else:
            print(f"⚠️  Exchange rates: Status code {response.status_code}")
            
    except Exception as e:
        print(f"❌ Currency converter test failed: {e}")

def main():
    """Run all tests"""
    print("🧪 Ghana-Square News System Tests")
    print("=" * 50)
    print(f"Testing server at: {BASE_URL}")
    print(f"Test time: {datetime.now()}")
    
    # Test health check first
    if not test_health_check():
        print("\n❌ Server is not running or not accessible")
        print("Please start the server using:")
        print("  Windows: start_server.bat")
        print("  Linux/Mac: ./start_server.sh")
        sys.exit(1)
    
    # Run all tests
    test_general_news()
    test_category_news()
    test_search()
    test_categorized_search()
    test_xml_api()
    test_cron_status()
    test_currency_converter()
    
    print("\n" + "=" * 50)
    print("🏁 Test suite completed!")
    print("\n💡 Tips:")
    print("- If some tests show warnings, it's normal - not all news sources may have data")
    print("- For better results, add your API keys to config.env")
    print("- Start cron jobs with: curl http://localhost:5000/api/cron/start")

if __name__ == "__main__":
    main()