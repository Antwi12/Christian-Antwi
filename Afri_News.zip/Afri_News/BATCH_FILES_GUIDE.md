# 🚀 Ghana-Square News - Batch Files Guide

## Quick Start Files

### 📂 **start_server.bat** - Main Server Startup
- ✅ **Use this daily** to start your news server
- 🚫 **No installation** - just starts the server
- ✅ **Fast startup** - checks Flask and starts immediately  
- ⚠️ **Prerequisites**: Dependencies must be installed first

**What it does:**
1. Finds Python (py, python, or python3)
2. Checks if Flask is installed
3. Creates database if needed
4. Starts the server at http://localhost:5000

---

### 📦 **install_dependencies.bat** - One-Time Setup  
- ⚠️ **Run once** when setting up for the first time
- ⚠️ **Run again** if you get Flask import errors
- 📋 **Installs** all required Python packages
- 🗃️ **Sets up** the database

**What it does:**
1. Finds Python installation
2. Upgrades pip
3. Installs Flask, requests, beautifulsoup4, etc.
4. Verifies installation
5. Creates database

---

### 🔧 **start_server_simple.bat** - Backup Option
- 🔄 **Alternative** if main batch file has issues
- ⚠️ **Installs dependencies** every time (slower)
- ✅ **More thorough** checks and error handling

---

## 📋 Usage Instructions

### First Time Setup:
```bash
1. Double-click: install_dependencies.bat
2. Wait for "Installation completed successfully!"
3. Double-click: start_server.bat
4. Open index.html in your browser
```

### Daily Usage:
```bash
1. Double-click: start_server.bat
2. Open index.html in your browser  
3. Keep the command window open while using the site
```

### If You Get Errors:
```bash
1. Run: install_dependencies.bat (reinstalls everything)
2. Then: start_server.bat
```

---

## 🎯 Expected Output

### ✅ **start_server.bat** Success:
```
=======================================
  Ghana-Square News Server
=======================================

✅ Found Python: py
Python 3.13.5
🔍 Checking if Flask is installed...
✅ Flask is installed
🚀 Starting Ghana-Square News Server...

📡 Server URL: http://localhost:5000
🔍 Health Check: http://localhost:5000/api/health
📰 Website: Open your index.html file

⚠️  Keep this window open while using the website
🛑 Press Ctrl+C to stop the server
========================================

* Running on all addresses (0.0.0.0)
* Running on http://127.0.0.1:5000
```

### ❌ **start_server.bat** Error:
```
❌ Flask not installed!
Please run: install_dependencies.bat first
```
**Solution**: Run `install_dependencies.bat` first

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| "Python not found" | Install Python from python.org, check "Add to PATH" |
| "Flask not installed" | Run `install_dependencies.bat` |
| Server won't start | Check if port 5000 is free, try `netstat -an \| find "5000"` |
| Import errors | Run `install_dependencies.bat` to reinstall |

---

## 🎉 Success Checklist

✅ `install_dependencies.bat` completed without errors  
✅ `start_server.bat` shows "Server URL: http://localhost:5000"  
✅ http://localhost:5000/api/health shows `{"status": "OK"}`  
✅ index.html loads news articles (not "No Image" placeholders)  
✅ All tabs work: Home, Business, Sports, Technology, Entertainment  
✅ Search function works with and without "Categorized" option  
✅ Currency converter modal opens and works  

**🎊 Your Ghana-Square News website is ready!**