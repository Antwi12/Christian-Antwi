@echo off
echo Testing the actual server startup...
echo.

echo Step 1: Testing Python path fix
set PYTHONPATH=C:\Users\user\AppData\Local\Programs\Python\Python313\Lib\site-packages;%PYTHONPATH%

echo Step 2: Testing Flask import with path fix
py -c "import sys; sys.path.insert(0, r'C:\Users\user\AppData\Local\Programs\Python\Python313\Lib\site-packages'); import flask; print('SUCCESS: Flask working!', flask.__version__)"

if not errorlevel 1 (
    echo Flask is working! Starting server...
    echo.
    py setup.py
    py app.py
) else (
    echo Flask still not working. Trying user install...
    py -m pip install --user --force-reinstall flask flask-cors requests beautifulsoup4
    echo.
    echo Testing after user install...
    py -c "import flask; print('Flask working after user install!', flask.__version__)"
    if not errorlevel 1 (
        py setup.py
        py app.py
    ) else (
        echo Still not working. Let's check what's in the directories...
        echo.
        echo Contents of site-packages:
        dir "C:\Users\user\AppData\Local\Programs\Python\Python313\Lib\site-packages" | findstr -i flask
        echo.
        echo Contents of user site-packages:
        for /f "tokens=*" %%i in ('py -c "import site; print(site.getusersitepackages())"') do dir "%%i" | findstr -i flask 2>nul
    )
)

pause