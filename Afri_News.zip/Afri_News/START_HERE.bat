@echo off
title Ghana-Square News - Smart Launcher
echo.
echo =======================================
echo   Ghana-Square News - Smart Launcher
echo =======================================
echo.

REM Find Python
set PYTHON_CMD=

py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    goto :check_setup
)

python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    goto :check_setup
)

python3 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python3
    goto :check_setup
)

echo Python not found! 
echo.
echo Please install Python from: https://python.org
echo Make sure to check "Add Python to PATH" during installation
echo.
pause
exit /b 1

:check_setup
echo Found Python: %PYTHON_CMD%
echo.

REM Check if virtual environment exists
if not exist "venv\Scripts\activate.bat" (
    echo Setting up for first time...
    echo.
    call FIXED_START.bat
    exit /b 0
)

REM Check if Flask is installed in venv
call venv\Scripts\activate.bat
python -c "import flask" >nul 2>&1
if not errorlevel 1 (
    echo Dependencies are ready! Starting server...
    echo.
    call start_server.bat
) else (
    echo Dependencies missing! Running setup...
    echo.
    call FIXED_START.bat
)