from flask import Flask, request, Response, jsonify
from flask_cors import CORS
import feedparser
import re
import requests
import sqlite3
import json
import xml.etree.ElementTree as ET
from urllib.parse import urlparse, quote_plus
import time
from datetime import datetime, timedelta
import threading
from apscheduler.schedulers.background import BackgroundScheduler
import dicttoxml
import hashlib
import os

app = Flask(__name__)
CORS(app)

# Configuration
NEWS_APIS = {
    'newsapi': {
        'key': 'your_newsapi_key_here',  # Replace with your actual API key
        'base_url': 'https://newsapi.org/v2/'
    },
    'gnews': {
        'key': 'your_gnews_key_here',  # Replace with your actual API key
        'base_url': 'https://gnews.io/api/v4/'
    }
}

# Database setup
def init_db():
    """Initialize the database"""
    conn = sqlite3.connect('news.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS news_articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            content TEXT,
            url TEXT UNIQUE NOT NULL,
            image_url TEXT,
            source TEXT,
            category TEXT,
            location TEXT,
            published_at DATETIME,
            fetched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            hash TEXT UNIQUE
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS fetch_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT,
            source TEXT,
            articles_count INTEGER,
            fetched_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def get_article_hash(title, url):
    """Generate hash for article to prevent duplicates"""
    return hashlib.md5(f"{title}{url}".encode()).hexdigest()

def save_article(article_data):
    """Save article to database, preventing duplicates"""
    conn = sqlite3.connect('news.db')
    cursor = conn.cursor()
    
    article_hash = get_article_hash(article_data['title'], article_data['url'])
    
    try:
        cursor.execute('''
            INSERT INTO news_articles 
            (title, description, content, url, image_url, source, category, location, published_at, hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            article_data['title'],
            article_data.get('description', ''),
            article_data.get('content', ''),
            article_data['url'],
            article_data.get('image_url'),
            article_data.get('source', ''),
            article_data.get('category', ''),
            article_data.get('location', ''),
            article_data.get('published_at'),
            article_hash
        ))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        # Article already exists
        return False
    finally:
        conn.close()

def get_articles_from_db(category=None, location=None, limit=20):
    """Retrieve articles from database"""
    conn = sqlite3.connect('news.db')
    cursor = conn.cursor()
    
    query = "SELECT * FROM news_articles"
    params = []
    conditions = []
    
    if category:
        conditions.append("category = ?")
        params.append(category)
    
    if location:
        conditions.append("location LIKE ?")
        params.append(f"%{location}%")
    
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    
    query += " ORDER BY published_at DESC LIMIT ?"
    params.append(limit)
    
    cursor.execute(query, params)
    articles = cursor.fetchall()
    conn.close()
    
    # Convert to dictionary format
    result = []
    for article in articles:
        result.append({
            'id': article[0],
            'title': article[1],
            'description': article[2],
            'content': article[3],
            'url': article[4],
            'image_url': article[5],
            'source': article[6],
            'category': article[7],
            'location': article[8],
            'published_at': article[9],
            'fetched_at': article[10]
        })
    
    return result

def validate_image_url(url):
    """Validate if URL is a valid image URL"""
    if not url or not isinstance(url, str):
        return False
    
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        return False
    
    valid_extensions = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp')
    if url.lower().endswith(valid_extensions):
        return True
    
    image_keywords = ['image', 'img', 'photo', 'picture', 'thumbnail', 'media']
    for keyword in image_keywords:
        if keyword in url.lower():
            return True
    
    return False

def extract_image_from_content(content):
    """Enhanced image URL extraction from HTML content - optimized for Google News"""
    if not content:
        return None
    
    # Clean the content first
    clean_content = content.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
    
    # Google News specific patterns - try most specific first
    patterns = [
        # Standard img tag with src
        r'<img[^>]+src=["\']([^"\']+)["\'][^>]*>',
        # Google News thumbnail patterns
        r'<img[^>]+src=["\']([^"\']*googleusercontent[^"\']*)["\'][^>]*>',
        r'<img[^>]+src=["\']([^"\']*gstatic[^"\']*)["\'][^>]*>',
        # Generic image URLs in content
        r'https?://[^\s<>"\']*\.(?:jpg|jpeg|png|gif|webp)(?:\?[^\s<>"\']*)?',
        # Google News specific image patterns
        r'https?://[^\s<>"\']*news\.google[^\s<>"\']*image[^\s<>"\']*',
        r'https?://[^\s<>"\']*googleusercontent[^\s<>"\']*\.(?:jpg|jpeg|png|gif|webp)',
        # Other common image hosting patterns
        r'https?://[^\s<>"\']*(?:image|img|photo|picture|thumbnail|media)[^\s<>"\']*\.(?:jpg|jpeg|png|gif|webp)',
        # Base64 images as last resort
        r'data:image/[^;]+;base64,[^"\'<>\s]+',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, clean_content, re.IGNORECASE)
        for match in matches:
            if isinstance(match, tuple):
                image_url = match[0]
            else:
                image_url = match
            
            # Clean and validate the URL
            image_url = image_url.strip()
            if image_url.startswith('//'):
                image_url = 'https:' + image_url
            
            # Validate the URL
            if image_url and (image_url.startswith('http') or image_url.startswith('data:')):
                return image_url
    
    return None

def get_rss2json_data(rss_url, limit=15):
    """Get data from RSS2JSON API"""
    try:
        rss2json_url = f"https://api.rss2json.com/v1/api.json?rss_url={quote_plus(rss_url)}"
        response = requests.get(rss2json_url, timeout=10)
        data = response.json()
        
        items = data.get('items', [])[:limit]
        processed_items = []
        
        for item in items:
            description = item.get('description', '')
            content = item.get('content', '')
            
            # Clean description
            if description:
                clean_desc = re.sub(r'<[^>]+>', '', description)
                clean_desc = clean_desc[:200] + "..." if len(clean_desc) > 200 else clean_desc
            else:
                clean_desc = "No description available."
            
            # Enhanced image extraction - try multiple sources
            image_url = None
            
            # Method 1: Check enclosure first (most reliable)
            if item.get('enclosure') and item['enclosure'].get('link'):
                image_url = item['enclosure']['link']
                print(f"Found image via enclosure: {image_url}")
            
            # Method 2: Check thumbnail
            elif item.get('thumbnail'):
                image_url = item['thumbnail']
                print(f"Found image via thumbnail: {image_url}")
            
            # Method 3: Extract from description
            elif description:
                image_url = extract_image_from_content(description)
                if image_url:
                    print(f"Found image via description: {image_url}")
            
            # Method 4: Extract from content if available
            elif content:
                image_url = extract_image_from_content(content)
                if image_url:
                    print(f"Found image via content: {image_url}")
            
            # Method 5: Try to get Google News thumbnail directly
            if not image_url and item.get('link'):
                # Google News articles sometimes have predictable thumbnail patterns
                link = item.get('link', '')
                if 'news.google.com' in link:
                    # This is a fallback - we'll try to use a placeholder or extract differently
                    pass
            
            # If no image found, use a local base64 placeholder
            if not image_url:
                print(f"No image found for article: {item.get('title', 'No title')[:50]}... Using local placeholder.")
                # Base64 encoded 400x200 blue news placeholder
                image_url = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWU0MGFmIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+"
            
            processed_item = {
                'title': item.get('title', 'No title'),
                'link': item.get('link', ''),
                'url': item.get('link', ''),
                'pubDate': item.get('pubDate', ''),
                'published': item.get('pubDate', ''),
                'description': clean_desc,
                'image': image_url,
                'image_url': image_url,
                'enclosure': {'link': image_url},
                'thumbnail': image_url
            }
            
            processed_items.append(processed_item)
        
        return processed_items
        
    except Exception as e:
        print(f"RSS2JSON Error: {e}")
        return []

def get_google_rss_direct(rss_url, limit=15):
    """Parse Google News RSS directly using feedparser - better for images"""
    try:
        print(f"Parsing Google RSS directly: {rss_url}")
        feed = feedparser.parse(rss_url)
        
        if not feed.entries:
            return []
        
        items = []
        for entry in feed.entries[:limit]:
            # Extract image from various sources
            image_url = None
            
            # Method 1: Media content/thumbnail
            if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
                image_url = entry.media_thumbnail[0]['url']
                print(f"Found image via media_thumbnail: {image_url}")
            
            # Method 2: Media content
            elif hasattr(entry, 'media_content') and entry.media_content:
                for media in entry.media_content:
                    if media.get('medium') == 'image' or 'image' in media.get('type', ''):
                        image_url = media.get('url')
                        print(f"Found image via media_content: {image_url}")
                        break
            
            # Method 3: Links with image type
            elif hasattr(entry, 'links'):
                for link in entry.links:
                    if link.get('type', '').startswith('image/'):
                        image_url = link.get('href')
                        print(f"Found image via links: {image_url}")
                        break
            
            # Method 4: Extract from description/summary
            description = getattr(entry, 'description', '') or getattr(entry, 'summary', '')
            if not image_url and description:
                image_url = extract_image_from_content(description)
                if image_url:
                    print(f"Found image via description parsing: {image_url}")
            
            # Method 5: Extract from content
            if not image_url and hasattr(entry, 'content') and entry.content:
                for content in entry.content:
                    image_url = extract_image_from_content(content.get('value', ''))
                    if image_url:
                        print(f"Found image via content parsing: {image_url}")
                        break
            
            # If no image found, use a local base64 placeholder
            if not image_url:
                print(f"No image found for: {entry.get('title', 'No title')[:50]}... Using local placeholder.")
                # Base64 encoded 400x200 blue news placeholder
                image_url = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWU0MGFmIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+"
            
            # Clean description
            clean_desc = description
            if clean_desc:
                clean_desc = re.sub(r'<[^>]+>', '', clean_desc)
                clean_desc = clean_desc[:200] + "..." if len(clean_desc) > 200 else clean_desc
            else:
                clean_desc = "No description available."
            
            item = {
                'title': entry.get('title', 'No title'),
                'link': entry.get('link', ''),
                'url': entry.get('link', ''),
                'pubDate': entry.get('published', ''),
                'published': entry.get('published', ''),
                'description': clean_desc,
                'image': image_url,
                'image_url': image_url,
                'enclosure': {'link': image_url},
                'thumbnail': image_url
            }
            
            items.append(item)
        
        print(f"Direct RSS parsing found {len([i for i in items if i.get('image')])} items with images out of {len(items)}")
        return items
        
    except Exception as e:
        print(f"Direct RSS parsing error: {e}")
        return []

def get_bbc_rss_direct(rss_url, limit=15, category='news'):
    """Parse BBC News RSS directly using feedparser - optimized for BBC image extraction"""
    try:
        print(f"Parsing BBC RSS directly: {rss_url}")
        feed = feedparser.parse(rss_url)
        
        if not feed.entries:
            print("No entries found in BBC RSS feed")
            return []
        
        items = []
        for entry in feed.entries[:limit]:
            # Extract image from various BBC RSS sources
            image_url = None
            
            # Method 1: Media thumbnail (BBC uses this frequently)
            if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
                for thumb in entry.media_thumbnail:
                    if thumb.get('url'):
                        image_url = thumb['url']
                        print(f"Found BBC image via media_thumbnail: {image_url}")
                        break
            
            # Method 2: Media content
            if not image_url and hasattr(entry, 'media_content') and entry.media_content:
                for media in entry.media_content:
                    if media.get('medium') == 'image' or 'image' in media.get('type', ''):
                        image_url = media.get('url')
                        print(f"Found BBC image via media_content: {image_url}")
                        break
            
            # Method 3: Look for BBC image URLs in links
            if not image_url and hasattr(entry, 'links'):
                for link in entry.links:
                    if link.get('type', '').startswith('image/'):
                        image_url = link.get('href')
                        print(f"Found BBC image via links: {image_url}")
                        break
            
            # Method 4: Extract from description/summary (BBC often embeds images)
            description = getattr(entry, 'description', '') or getattr(entry, 'summary', '')
            if not image_url and description:
                # BBC specific image patterns
                bbc_patterns = [
                    r'<img[^>]+src=["\']([^"\']*ichef\.bbci\.co\.uk[^"\']*)["\'][^>]*>',
                    r'<img[^>]+src=["\']([^"\']*bbc\.co\.uk[^"\']*\.jpg)["\'][^>]*>',
                    r'<img[^>]+src=["\']([^"\']*bbc\.com[^"\']*\.jpg)["\'][^>]*>',
                ]
                
                for pattern in bbc_patterns:
                    match = re.search(pattern, description, re.IGNORECASE)
                    if match:
                        image_url = match.group(1)
                        print(f"Found BBC image via description: {image_url}")
                        break
                
                # Fallback to general image extraction
                if not image_url:
                    image_url = extract_image_from_content(description)
                    if image_url:
                        print(f"Found BBC image via content extraction: {image_url}")
            
            # Method 5: BBC specific enclosure handling
            if not image_url and hasattr(entry, 'enclosures'):
                for enclosure in entry.enclosures:
                    if enclosure.get('type', '').startswith('image/'):
                        image_url = enclosure.get('href')
                        print(f"Found BBC image via enclosures: {image_url}")
                        break
            
            if not image_url:
                print(f"No BBC image found for: {entry.get('title', 'No title')[:50]}...")
            
            # Clean description
            clean_desc = description
            if clean_desc:
                # Remove HTML tags
                clean_desc = re.sub(r'<[^>]+>', '', clean_desc)
                # Clean BBC-specific artifacts
                clean_desc = re.sub(r'This article contains affiliate links.*', '', clean_desc)
                clean_desc = clean_desc.strip()
                clean_desc = clean_desc[:250] + "..." if len(clean_desc) > 250 else clean_desc
            else:
                clean_desc = "No description available."
            
            # Format publication date
            pub_date = entry.get('published', '') or entry.get('updated', '')
            
            item = {
                'title': entry.get('title', 'No title'),
                'link': entry.get('link', ''),
                'url': entry.get('link', ''),
                'pubDate': pub_date,
                'published': pub_date,
                'description': clean_desc,
                'image': image_url,
                'image_url': image_url,
                'enclosure': {'link': image_url} if image_url else None,
                'thumbnail': image_url,
                'source': f'BBC {category.title()}',
                'category': category
            }
            
            items.append(item)
        
        images_found = len([i for i in items if i.get('image')])
        print(f"BBC RSS parsing found {images_found} items with images out of {len(items)} total")
        return items
        
    except Exception as e:
        print(f"BBC RSS parsing error: {e}")
        return []

def fetch_newsapi_data(query, category=None, limit=15):
    """Fetch data from NewsAPI"""
    try:
        api_key = NEWS_APIS['newsapi']['key']
        if api_key == 'your_newsapi_key_here':
            return []
        
        base_url = NEWS_APIS['newsapi']['base_url']
        
        if category:
            url = f"{base_url}top-headlines?category={category}&country=gh&apiKey={api_key}&pageSize={limit}"
        else:
            url = f"{base_url}everything?q={query}&language=en&apiKey={api_key}&pageSize={limit}"
        
        response = requests.get(url, timeout=10)
        data = response.json()
        
        if data.get('status') != 'ok':
            return []
        
        articles = data.get('articles', [])
        processed_items = []
        
        for article in articles:
            processed_item = {
                'title': article.get('title', 'No title'),
                'link': article.get('url', ''),
                'url': article.get('url', ''),
                'published': article.get('publishedAt', ''),
                'pubDate': article.get('publishedAt', ''),
                'description': article.get('description', ''),
                'image': article.get('urlToImage'),
                'image_url': article.get('urlToImage'),
                'source': article.get('source', {}).get('name', ''),
                'enclosure': {'link': article.get('urlToImage')} if article.get('urlToImage') else None
            }
            processed_items.append(processed_item)
        
        return processed_items
        
    except Exception as e:
        print(f"NewsAPI Error: {e}")
        return []

def fetch_gnews_data(query, category=None, limit=15):
    """Fetch data from GNews API"""
    try:
        api_key = NEWS_APIS['gnews']['key']
        if api_key == 'your_gnews_key_here':
            return []
        
        base_url = NEWS_APIS['gnews']['base_url']
        
        if category:
            url = f"{base_url}top-headlines?category={category}&country=gh&token={api_key}&max={limit}"
        else:
            url = f"{base_url}search?q={query}&lang=en&country=gh&token={api_key}&max={limit}"
        
        response = requests.get(url, timeout=10)
        data = response.json()
        
        articles = data.get('articles', [])
        processed_items = []
        
        for article in articles:
            processed_item = {
                'title': article.get('title', 'No title'),
                'link': article.get('url', ''),
                'url': article.get('url', ''),
                'published': article.get('publishedAt', ''),
                'pubDate': article.get('publishedAt', ''),
                'description': article.get('description', ''),
                'image': article.get('image'),
                'image_url': article.get('image'),
                'source': article.get('source', {}).get('name', ''),
                'enclosure': {'link': article.get('image')} if article.get('image') else None
            }
            processed_items.append(processed_item)
        
        return processed_items
        
    except Exception as e:
        print(f"GNews Error: {e}")
        return []

def categorize_news_by_location(query):
    """Categorize news by location across different topics"""
    categories = ['business', 'sports', 'technology', 'entertainment']
    categorized_results = {}
    
    for category in categories:
        # Try different APIs and combine results
        results = []
        
        # Try NewsAPI
        newsapi_results = fetch_newsapi_data(f"{query} {category}", category)
        results.extend(newsapi_results[:5])
        
        # Try GNews
        gnews_results = fetch_gnews_data(f"{query} {category}", category)
        results.extend(gnews_results[:5])
        
        # Try RSS feeds
        google_rss = f"https://news.google.com/rss/search?q={quote_plus(f'{query} {category}')}&hl=en-GH&gl=GH&ceid=GH:en"
        rss_results = get_rss2json_data(google_rss, 5)
        results.extend(rss_results)
        
        # Remove duplicates and limit results
        seen_urls = set()
        unique_results = []
        for result in results:
            if result['url'] not in seen_urls:
                seen_urls.add(result['url'])
                unique_results.append(result)
        
        categorized_results[category] = unique_results[:10]
    
    return categorized_results

# API Routes

@app.route('/api/health')
def health_check():
    return jsonify({"status": "healthy", "timestamp": time.time()})

@app.route('/api/test-business')
def test_business():
    """Test endpoint to debug BBC business news data"""
    try:
        bbc_rss = 'http://feeds.bbci.co.uk/news/business/rss.xml'
        
        print(f"Testing BBC Business RSS: {bbc_rss}")
        items = get_bbc_rss_direct(bbc_rss, 5, 'business')
        
        # Return detailed debug info
        result = {
            "source": "BBC Business News",
            "rss_url": bbc_rss,
            "items_count": len(items),
            "items_with_images": len([i for i in items if i.get('image')]),
            "sample_items": items[:2] if items else []  # First 2 items for debugging
        }
        
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/api/test-bbc-all')
def test_bbc_all():
    """Test all BBC RSS feeds"""
    try:
        bbc_feeds = {
            'business': 'http://feeds.bbci.co.uk/news/business/rss.xml',
            'sports': 'http://feeds.bbci.co.uk/sport/rss.xml',
            'technology': 'http://feeds.bbci.co.uk/news/technology/rss.xml',
            'entertainment': 'http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml'
        }
        
        results = {}
        for category, rss_url in bbc_feeds.items():
            print(f"Testing BBC {category}: {rss_url}")
            items = get_bbc_rss_direct(rss_url, 3, category)
            
            results[category] = {
                "rss_url": rss_url,
                "items_count": len(items),
                "items_with_images": len([i for i in items if i.get('image')]),
                "sample_title": items[0]['title'] if items else "No articles found"
            }
        
        return jsonify({
            "status": "BBC RSS feeds tested",
            "results": results
        })
        
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/api/test-bbc-search/<query>')
def test_bbc_search(query):
    """Test BBC search functionality"""
    try:
        print(f"Testing BBC Search for: '{query}'")
        
        # Use our BBC search function
        search_results = search_news(query).get_json()
        
        # Analyze results
        total_results = len(search_results)
        results_with_images = len([r for r in search_results if r.get('image')])
        categories_found = list(set([r.get('search_category', 'unknown') for r in search_results]))
        
        return jsonify({
            "status": "BBC Search tested",
            "query": query,
            "total_results": total_results,
            "results_with_images": results_with_images,
            "categories_found": categories_found,
            "sample_results": search_results[:3] if search_results else [],
            "relevance_scores": [r.get('relevance_score', 0) for r in search_results[:5]]
        })
        
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/api/news')
def get_news():
    """Get general news from Yahoo RSS"""
    try:
        rss_url = "https://news.yahoo.com/rss/"
        feed = feedparser.parse(rss_url)
        news_items = []
        
        for entry in feed.entries[:15]:
            image_url = None
            
            if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
                image_url = entry.media_thumbnail[0]['url']
            elif hasattr(entry, 'enclosures') and entry.enclosures:
                for enclosure in entry.enclosures:
                    if enclosure.type and enclosure.type.startswith('image'):
                        image_url = enclosure.href
                        break
            elif hasattr(entry, 'summary'):
                image_url = extract_image_from_content(entry.summary)
            elif hasattr(entry, 'media_content') and entry.media_content:
                image_url = entry.media_content[0]['url']
            
            description = ""
            if hasattr(entry, 'summary'):
                description = re.sub(r'<[^>]+>', '', entry.summary)
                description = description[:200] + "..." if len(description) > 200 else description
            
            news_item = {
                'title': entry.title,
                'link': entry.link,
                'url': entry.link,
                'published': entry.published,
                'pubDate': entry.published,
                'description': description,
                'image': image_url,
                'image_url': image_url,
                'enclosure': {'link': image_url} if image_url else None
            }
            
            news_items.append(news_item)
        
        return jsonify(news_items)
        
    except Exception as e:
        print(f"Yahoo RSS Error: {e}")
        return jsonify([])

@app.route('/api/google-news/<category>')
def get_bbc_news(category):
    """Get BBC News RSS feeds with guaranteed images"""
    try:
        # BBC RSS feeds for different categories
        bbc_feeds = {
            'business': 'http://feeds.bbci.co.uk/news/business/rss.xml',
            'sports': 'http://feeds.bbci.co.uk/sport/rss.xml',
            'technology': 'http://feeds.bbci.co.uk/news/technology/rss.xml',
            'entertainment': 'http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml'
        }
        
        # Get the BBC RSS feed for this category
        bbc_rss = bbc_feeds.get(category)
        if not bbc_rss:
            print(f"Invalid category: {category}")
            return jsonify([])
        
        print(f"Fetching BBC News for {category}: {bbc_rss}")
        
        # Use direct RSS parsing for better BBC image extraction
        items = get_bbc_rss_direct(bbc_rss, 15, category)
        
        # Ensure ALL items have images (local base64 placeholders as fallback)
        for item in items:
            if not item.get('image') or item.get('image') == 'default.jpg':
                # Category-specific BBC-style placeholder images
                placeholders = {
                    'business': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMDA1OTY5O3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjQiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QlVTSU5FU1M8L3RleHQ+PHRleHQgeD0iNTAlIiB5PSI3MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+",
                    'sports': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojZGMyNjI2O3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDIFNQT1JUID48L3RleHQ+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5TUE9SVFM8L3RleHQ+PHRleHQgeD0iNTAlIiB5PSI3MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5FV1M8L3RleHQ+PC9zdmc+",
                    'technology': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojN2MzYWVkO3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+VEVDSE5PTE9HWTwvdGV4dD48dGV4dCB4PSI1MCUiIHk9IjcwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+TkVXUzwvdGV4dD48L3N2Zz4=",
                    'entertainment': "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojZWE1ODBjO3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjMwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+RU5URVJUQUlOTUVOVDwvdGV4dD48dGV4dCB4PSI1MCUiIHk9IjcwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+TkVXUzwvdGV4dD48L3N2Zz4="
                }
                placeholder = placeholders.get(category, "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjQkIxMDE3Ii8+PHRleHQgeD0iNTAlIiB5PSI0MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iI2ZmZmZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkJCQzwvdGV4dD48dGV4dCB4PSI1MCUiIHk9IjYwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjIwIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+TkVXUzwvdGV4dD48L3N2Zz4=")
                
                item['image'] = placeholder
                item['image_url'] = placeholder
                item['enclosure'] = {'link': placeholder}
                item['thumbnail'] = placeholder
                
                print(f"Added BBC {category} placeholder for: {item.get('title', '')[:50]}...")
        
        print(f"Returning {len(items)} BBC {category} articles, all with images")
        return jsonify(items)
        
    except Exception as e:
        print(f"BBC News Error for {category}: {e}")
        return jsonify([])

@app.route('/api/search/<query>')
def search_news(query):
    """Search news using BBC RSS feeds with smart filtering"""
    try:
        print(f"BBC Search for: '{query}'")
        
        # BBC RSS feeds to search across
        bbc_search_feeds = {
            'general': 'http://feeds.bbci.co.uk/news/rss.xml',
            'world': 'http://feeds.bbci.co.uk/news/world/rss.xml',
            'business': 'http://feeds.bbci.co.uk/news/business/rss.xml',
            'technology': 'http://feeds.bbci.co.uk/news/technology/rss.xml',
            'entertainment': 'http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml',
            'sports': 'http://feeds.bbci.co.uk/sport/rss.xml',
            'health': 'http://feeds.bbci.co.uk/news/health/rss.xml',
            'science': 'http://feeds.bbci.co.uk/news/science_and_environment/rss.xml'
        }
        
        all_results = []
        query_lower = query.lower()
        
        # Search through BBC feeds
        for feed_name, feed_url in bbc_search_feeds.items():
            print(f"Searching BBC {feed_name} feed...")
            try:
                feed_items = get_bbc_rss_direct(feed_url, 20, feed_name)
                
                # Filter items that match the search query
                for item in feed_items:
                    title = item.get('title', '').lower()
                    description = item.get('description', '').lower()
                    
                    # Smart search matching
                    if (query_lower in title or 
                        query_lower in description or
                        any(word in title for word in query_lower.split()) or
                        any(word in description for word in query_lower.split())):
                        
                        # Add relevance score
                        score = 0
                        if query_lower in title:
                            score += 10
                        if query_lower in description:
                            score += 5
                        for word in query_lower.split():
                            if word in title:
                                score += 3
                            if word in description:
                                score += 1
                        
                        item['relevance_score'] = score
                        item['search_category'] = feed_name
                        all_results.append(item)
                        
            except Exception as feed_error:
                print(f"Error searching BBC {feed_name}: {feed_error}")
                continue
        
        # Sort by relevance score and limit results
        all_results.sort(key=lambda x: x.get('relevance_score', 0), reverse=True)
        final_results = all_results[:20]  # Top 20 most relevant
        
        # Add BBC search placeholders for items without images
        for item in final_results:
            if not item.get('image'):
                item['image'] = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiNCQjEwMTc7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMDA1OTY5O3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiLz48dGV4dCB4PSI1MCUiIHk9IjQwJSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE2IiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+QkJDPC90ZXh0Pjx0ZXh0IHg9IjUwJSIgeT0iNjAlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTgiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjZmZmZmZmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+U0VBUkNIPC90ZXh0Pjwvc3ZnPg=="
                item['image_url'] = item['image']
                item['enclosure'] = {'link': item['image']}
                item['thumbnail'] = item['image']
            
            # Update source to show it's BBC Search
            item['source'] = f"BBC {item.get('search_category', 'Search').title()}"
        
        print(f"BBC Search found {len(final_results)} relevant articles for '{query}'")
        return jsonify(final_results)
        
    except Exception as e:
        print(f"BBC Search Error: {e}")
        # Fallback to Google News if BBC search fails
        try:
            enhanced_query = f"{query} news"
            search_rss = f"https://news.google.com/rss/search?q={quote_plus(enhanced_query)}&hl=en-GH&gl=GH&ceid=GH:en"
            items = get_rss2json_data(search_rss, 15)
            print(f"Fallback to Google News search returned {len(items)} items")
            return jsonify(items)
        except:
            return jsonify([])

@app.route('/getnews', methods=['GET'])
def getnews():
    """API endpoint for XML news results with query parameters"""
    try:
        topic = request.args.get('topic', 'general')
        category = request.args.get('category', '')
        location = request.args.get('location', '')
        format_type = request.args.get('format', 'xml')
        
        if location and not category:
            # Categorized search by location
            results = categorize_news_by_location(location)
        else:
            # Regular search
            if category:
                results = fetch_newsapi_data(topic, category)
                if not results:
                    google_rss = f"https://news.google.com/rss/search?q={quote_plus(topic)}&hl=en-GH&gl=GH&ceid=GH:en"
                    results = get_rss2json_data(google_rss)
            else:
                results = get_rss2json_data(f"https://news.google.com/rss/search?q={quote_plus(topic)}&hl=en-GH&gl=GH&ceid=GH:en")
        
        # Save to database
        saved_count = 0
        if isinstance(results, list):
            for article in results:
                article_data = {
                    'title': article.get('title', ''),
                    'description': article.get('description', ''),
                    'url': article.get('url', article.get('link', '')),
                    'image_url': article.get('image_url', article.get('image')),
                    'source': article.get('source', 'RSS Feed'),
                    'category': category,
                    'location': location,
                    'published_at': article.get('published', article.get('pubDate'))
                }
                if save_article(article_data):
                    saved_count += 1
        
        # Log the fetch
        conn = sqlite3.connect('news.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO fetch_logs (query, source, articles_count) VALUES (?, ?, ?)', 
                      (topic, 'API', saved_count))
        conn.commit()
        conn.close()
        
        if format_type.lower() == 'json':
            return jsonify(results)
        else:
            # Return XML
            xml_data = dicttoxml.dicttoxml(results, custom_root='news', attr_type=False)
            return Response(xml_data, mimetype='application/xml')
        
    except Exception as e:
        print(f"GetNews Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/categorized-search/<location>')
def categorized_search(location):
    """Get categorized news by location"""
    try:
        results = categorize_news_by_location(location)
        return jsonify(results)
    except Exception as e:
        print(f"Categorized Search Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/database/articles')
def get_database_articles():
    """Get articles from database"""
    try:
        category = request.args.get('category')
        location = request.args.get('location')
        limit = int(request.args.get('limit', 20))
        
        articles = get_articles_from_db(category, location, limit)
        return jsonify(articles)
    except Exception as e:
        print(f"Database Articles Error: {e}")
        return jsonify({"error": str(e)}), 500

# Cron job functions
def fetch_and_store_news(topic="Ghana", categories=None):
    """Automated news fetching function"""
    if categories is None:
        categories = ['business', 'sports', 'technology', 'entertainment']
    
    total_saved = 0
    
    for category in categories:
        try:
            # Fetch from multiple sources
            query = f"{topic} {category}"
            
            # NewsAPI
            newsapi_results = fetch_newsapi_data(query, category)
            
            # GNews  
            gnews_results = fetch_gnews_data(query, category)
            
            # RSS
            google_rss = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl=en-GH&gl=GH&ceid=GH:en"
            rss_results = get_rss2json_data(google_rss)
            
            # Combine results
            all_results = newsapi_results + gnews_results + rss_results
            
            # Remove duplicates
            seen_urls = set()
            unique_results = []
            for result in all_results:
                url = result.get('url', result.get('link', ''))
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    unique_results.append(result)
            
            # Save to database
            saved_count = 0
            for article in unique_results:
                article_data = {
                    'title': article.get('title', ''),
                    'description': article.get('description', ''),
                    'content': article.get('content', ''),
                    'url': article.get('url', article.get('link', '')),
                    'image_url': article.get('image_url', article.get('image')),
                    'source': article.get('source', 'Auto Fetch'),
                    'category': category,
                    'location': topic,
                    'published_at': article.get('published', article.get('pubDate'))
                }
                if save_article(article_data):
                    saved_count += 1
            
            total_saved += saved_count
            
            # Log the fetch
            conn = sqlite3.connect('news.db')
            cursor = conn.cursor()
            cursor.execute('INSERT INTO fetch_logs (query, source, articles_count) VALUES (?, ?, ?)', 
                          (f"{topic} {category}", 'Cron Job', saved_count))
            conn.commit()
            conn.close()
            
            print(f"Saved {saved_count} articles for {category}")
            
        except Exception as e:
            print(f"Error fetching {category} news: {e}")
    
    print(f"Total saved articles: {total_saved}")
    return total_saved

# Initialize scheduler
scheduler = BackgroundScheduler()

@app.route('/api/cron/start')
def start_cron():
    """Start the cron job"""
    try:
        # Fetch news every 30 minutes
        scheduler.add_job(
            func=fetch_and_store_news,
            trigger="interval",
            minutes=30,
            id='fetch_news_job',
            kwargs={'topic': 'Ghana', 'categories': ['business', 'sports', 'technology', 'entertainment']},
            replace_existing=True
        )
        
        if not scheduler.running:
            scheduler.start()
        
        return jsonify({"status": "Cron job started", "interval": "30 minutes"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/cron/stop')
def stop_cron():
    """Stop the cron job"""
    try:
        scheduler.remove_job('fetch_news_job')
        return jsonify({"status": "Cron job stopped"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/cron/status')
def cron_status():
    """Get cron job status"""
    try:
        jobs = scheduler.get_jobs()
        return jsonify({
            "running": scheduler.running,
            "jobs": len(jobs),
            "job_details": [{"id": job.id, "next_run": str(job.next_run_time)} for job in jobs]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Currency Converter API Endpoints
@app.route('/api/currency/convert', methods=['GET', 'POST'])
def convert_currency():
    """Convert currency using multiple APIs with fallbacks"""
    try:
        if request.method == 'POST':
            data = request.get_json()
            amount = data.get('amount')
            from_currency = data.get('from_currency', '').upper()
            to_currency = data.get('to_currency', '').upper()
        else:
            amount = request.args.get('amount')
            from_currency = request.args.get('from_currency', '').upper()
            to_currency = request.args.get('to_currency', '').upper()
        
        # Validate inputs
        if not amount or not from_currency or not to_currency:
            return jsonify({
                "error": "Missing required parameters: amount, from_currency, to_currency"
            }), 400
        
        try:
            amount = float(amount)
        except ValueError:
            return jsonify({"error": "Invalid amount format"}), 400
        
        # Try multiple currency APIs with fallbacks
        conversion_result = None
        
        # API 1: ExchangeRate-API (Free tier)
        try:
            response = requests.get(f"https://api.exchangerate-api.com/v4/latest/{from_currency}", timeout=10)
            if response.status_code == 200:
                data = response.json()
                if to_currency in data.get('rates', {}):
                    rate = data['rates'][to_currency]
                    converted_amount = amount * rate
                    conversion_result = {
                        "amount": amount,
                        "from_currency": from_currency,
                        "to_currency": to_currency,
                        "exchange_rate": rate,
                        "converted_amount": round(converted_amount, 2),
                        "source": "ExchangeRate-API",
                        "timestamp": data.get('date', time.strftime('%Y-%m-%d'))
                    }
        except Exception as e:
            print(f"ExchangeRate-API failed: {e}")
        
        # API 2: Fixer.io fallback (requires API key)
        if not conversion_result:
            try:
                # You can add your Fixer.io API key here
                fixer_api_key = "your_fixer_api_key_here"  # Replace with actual key
                if fixer_api_key != "your_fixer_api_key_here":
                    response = requests.get(
                        f"http://data.fixer.io/api/latest?access_key={fixer_api_key}&base={from_currency}&symbols={to_currency}",
                        timeout=10
                    )
                    if response.status_code == 200:
                        data = response.json()
                        if data.get('success') and to_currency in data.get('rates', {}):
                            rate = data['rates'][to_currency]
                            converted_amount = amount * rate
                            conversion_result = {
                                "amount": amount,
                                "from_currency": from_currency,
                                "to_currency": to_currency,
                                "exchange_rate": rate,
                                "converted_amount": round(converted_amount, 2),
                                "source": "Fixer.io",
                                "timestamp": data.get('date', time.strftime('%Y-%m-%d'))
                            }
            except Exception as e:
                print(f"Fixer.io API failed: {e}")
        
        # API 3: CurrencyLayer fallback (requires API key)
        if not conversion_result:
            try:
                currencylayer_api_key = "your_currencylayer_api_key_here"  # Replace with actual key
                if currencylayer_api_key != "your_currencylayer_api_key_here":
                    response = requests.get(
                        f"http://api.currencylayer.com/live?access_key={currencylayer_api_key}&currencies={to_currency}&source={from_currency}",
                        timeout=10
                    )
                    if response.status_code == 200:
                        data = response.json()
                        if data.get('success'):
                            quote_key = f"{from_currency}{to_currency}"
                            if quote_key in data.get('quotes', {}):
                                rate = data['quotes'][quote_key]
                                converted_amount = amount * rate
                                conversion_result = {
                                    "amount": amount,
                                    "from_currency": from_currency,
                                    "to_currency": to_currency,
                                    "exchange_rate": rate,
                                    "converted_amount": round(converted_amount, 2),
                                    "source": "CurrencyLayer",
                                    "timestamp": time.strftime('%Y-%m-%d')
                                }
            except Exception as e:
                print(f"CurrencyLayer API failed: {e}")
        
        if conversion_result:
            return jsonify(conversion_result)
        else:
            return jsonify({
                "error": "Currency conversion failed. Please check currency codes and try again."
            }), 503
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/currency/rates/<base_currency>')
def get_exchange_rates(base_currency):
    """Get all exchange rates for a base currency"""
    try:
        base_currency = base_currency.upper()
        
        # Try ExchangeRate-API first
        try:
            response = requests.get(f"https://api.exchangerate-api.com/v4/latest/{base_currency}", timeout=10)
            if response.status_code == 200:
                data = response.json()
                return jsonify({
                    "base_currency": base_currency,
                    "rates": data.get('rates', {}),
                    "source": "ExchangeRate-API",
                    "timestamp": data.get('date', time.strftime('%Y-%m-%d'))
                })
        except Exception as e:
            print(f"ExchangeRate-API failed: {e}")
        
        return jsonify({
            "error": f"Failed to get exchange rates for {base_currency}"
        }), 503
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/currency/supported')
def get_supported_currencies():
    """Get list of supported currencies"""
    try:
        # Common currencies - you can expand this list
        supported_currencies = {
            "USD": "US Dollar",
            "EUR": "Euro",
            "GBP": "British Pound",
            "GHS": "Ghanaian Cedi",
            "NGN": "Nigerian Naira",
            "KES": "Kenyan Shilling",
            "ZAR": "South African Rand",
            "JPY": "Japanese Yen",
            "CNY": "Chinese Yuan",
            "CAD": "Canadian Dollar",
            "AUD": "Australian Dollar",
            "CHF": "Swiss Franc",
            "INR": "Indian Rupee",
            "BRL": "Brazilian Real",
            "RUB": "Russian Ruble",
            "MXN": "Mexican Peso",
            "SGD": "Singapore Dollar",
            "HKD": "Hong Kong Dollar",
            "NOK": "Norwegian Krone",
            "SEK": "Swedish Krona",
            "DKK": "Danish Krone",
            "PLN": "Polish Zloty",
            "CZK": "Czech Koruna",
            "HUF": "Hungarian Forint",
            "TRY": "Turkish Lira",
            "ILS": "Israeli Shekel"
        }
        
        return jsonify({
            "supported_currencies": supported_currencies,
            "count": len(supported_currencies)
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    init_db()
    # Use environment variable for port, default to 5001 to avoid conflicts
    port = int(os.environ.get('FLASK_PORT', 5001))
    app.run(debug=True, host='0.0.0.0', port=port)