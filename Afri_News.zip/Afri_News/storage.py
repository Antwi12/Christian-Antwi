import dicttoxml
import sqlite3

def save_to_xml(data, filename='news_results.xml'):
    xml_data = dicttoxml.dicttoxml(data)
    with open(filename, 'wb') as f:
        f.write(xml_data)

def save_to_db(articles):
    conn = sqlite3.connect('news.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            url TEXT UNIQUE,
            publishedAt TEXT,
            source TEXT,
            topic TEXT
        )
    ''')
    for a in articles:
        c.execute('INSERT OR IGNORE INTO articles VALUES (NULL,?,?,?,?,?,?)', (
            a['title'], a['description'], a['url'], a['publishedAt'],
            a['source']['name'], a.get('topic', '')
        ))
    conn.commit()
    conn.close()
