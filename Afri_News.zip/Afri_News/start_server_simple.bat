@echo off
echo.
echo =======================================
echo   Ghana-Square News Server Startup
echo =======================================
echo.

REM Find Python
py --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python launcher 'py' not found
    pause
    exit /b 1
)

echo Found Python:
py --version

REM Install/upgrade pip
echo.
echo Ensuring pip is up to date...
py -m pip install --upgrade pip

REM Install dependencies
echo.
echo Installing dependencies...
if exist "requirements.txt" (
    py -m pip install -r requirements.txt
) else (
    echo Installing Flask and dependencies manually...
    py -m pip install flask flask-cors requests beautifulsoup4 apscheduler
)

REM Check if Flask is installed
echo.
echo Checking Flask installation...
py -c "import flask; print('✅ Flask installed successfully')" 2>nul
if errorlevel 1 (
    echo ❌ Flask installation failed. Installing manually...
    py -m pip install flask flask-cors requests beautifulsoup4 apscheduler
)

REM Run setup script if database doesn't exist
if not exist "news.db" (
    echo.
    echo Running initial setup...
    py setup.py
)

REM Start the Flask application
echo.
echo ========================================
echo Starting Flask application...
echo Server will be available at: http://localhost:5000
echo API Health Check: http://localhost:5000/api/health
echo.
echo Press Ctrl+C to stop the server
echo ========================================
echo.

py app.py

echo.
echo Server stopped.
pause