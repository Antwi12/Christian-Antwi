import pandas as pd

import numpy as np

import matplotlib.pyplot as plt

import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression

from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

sns.set_style("whitegrid")

plt.rcParams["figure.figsize"] = (8, 5)

# =========================

# Task 1: Import Data

# =========================

df = pd.read_csv("train.csv")

# Display basics

print("Dimensions:", df.shape)

print("\nColumn Names:\n", df.columns.tolist())

print("\nFirst 5 rows:\n", df.head())

print("\nData Types:\n", df.dtypes)

# Interpretation:

# 891 rows, 12 columns.

# Target variable is Survived.

# The dataset contains both numerical and categorical variables.

# =========================

# Task 2: Data Cleaning

# =========================

# 1. Missing values

print("\nMissing values before cleaning:\n", df.isnull().sum())

# 2. Handle missing values

# Age: fill missing values with median age by passenger class

df["Age"] = df.groupby("Pclass")["Age"].transform(

    lambda x: x.fillna(x.median())

)

# Embarked: fill missing values with mode

df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

# Cabin: too many missing values, so drop it

df = df.drop("Cabin", axis=1)

# 3. Duplicates

print("\nDuplicates:", df.duplicated().sum())

df = df.drop_duplicates()

print("\nMissing values after cleaning:\n", df.isnull().sum())

# Explanation:

# Median was used for Age because Age is skewed and differs by class.

# Mode was used for Embarked because it is categorical.

# Cabin was dropped because it has too many missing values.

# =========================

# Task 3: Data Visualisation

# =========================

# 1. Histogram of Age

plt.figure()

sns.histplot(df["Age"], bins=30, kde=True)

plt.title("Distribution of Passenger Ages")

plt.xlabel("Age")

plt.ylabel("Count")

plt.savefig("histogram_age.png")

plt.close()

# 2. Bar chart: Pclass distribution

plt.figure()

sns.countplot(x="Pclass", data=df, palette="pastel")

plt.title("Passenger Class Distribution")

plt.xlabel("Passenger Class")

plt.ylabel("Count")

plt.savefig("bar_pclass.png")

plt.close()

# 3. Boxplot: Age by Pclass

plt.figure()

sns.boxplot(x="Pclass", y="Age", data=df)

plt.title("Age Distribution by Passenger Class")

plt.xlabel("Passenger Class")

plt.ylabel("Age")

plt.savefig("boxplot_age_pclass.png")

plt.close()

# 4. Scatter plot: Age vs Fare

plt.figure()

sns.scatterplot(x="Age", y="Fare", hue="Survived", data=df, alpha=0.6)

plt.title("Age vs Fare Colored by Survival")

plt.xlabel("Age")

plt.ylabel("Fare")

plt.savefig("scatter_age_fare.png")

plt.close()

# 5. Correlation Heatmap

plt.figure()

numeric_df = df.select_dtypes(include=np.number)

sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm")

plt.title("Correlation Heatmap")

plt.savefig("heatmap_corr.png")

plt.close()

# 6. Pairplot

sns.pairplot(df[["Age", "Fare", "Pclass", "Survived"]], hue="Survived")

plt.suptitle("Pairplot of Selected Variables", y=1.02)

plt.savefig("pairplot.png")

plt.close()

print("\nAll visualizations saved as PNG files.")

# =========================

# Task 4: Statistical Analysis

# =========================

# 1. Descriptive statistics

print("\nDescriptive Statistics:\n", df.describe())

# 2. Frequency distribution

print("\nPclass Frequency Distribution:\n")

print(df["Pclass"].value_counts(normalize=True))

print("\nSurvived Frequency Distribution:\n")

print(df["Survived"].value_counts(normalize=True))

# 3. Correlation

numeric_df = df.select_dtypes(include=np.number)

corr = numeric_df.corr()

print("\nCorrelation with Survived:\n")

print(corr["Survived"].sort_values(ascending=False))

# 4. Strongest positive correlation with Survived

pos = corr["Survived"].sort_values(ascending=False).index[1]

# 5. Strongest negative correlation with Survived

neg = corr["Survived"].sort_values().index[0]

print(f"\nStrongest Positive Correlation with Survived: {pos}")

print(f"Strongest Negative Correlation with Survived: {neg}")

# Important findings:

# Finding 1: Fare is positively related to survival.

# Finding 2: Pclass is negatively related to survival because lower class numbers mean higher class.

# Finding 3: Age has a weak relationship with survival, although children had better chances.

# =========================

# Task 5: Machine Learning Model

# =========================

# 1. Feature selection and encoding

features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]

X = df[features]

y = df["Survived"]

# Encode categorical variables

X = pd.get_dummies(X, columns=["Sex", "Embarked"], drop_first=True)

# 2. Train-test split

X_train, X_test, y_train, y_test = train_test_split(

    X,

    y,

    test_size=0.2,

    random_state=42

)

# 3. Train model

model = LogisticRegression(max_iter=1000)

model.fit(X_train, y_train)

# 4. Predict

y_pred = model.predict(X_test)

# 5. Evaluate

print("\nAccuracy:", accuracy_score(y_test, y_pred))

print("\nConfusion Matrix:\n")

print(confusion_matrix(y_test, y_pred))

print("\nClassification Report:\n")

print(classification_report(y_test, y_pred))

# Interpretation:

# An accuracy around 78% to 82% is a typical baseline result for the Titanic dataset.

# Precision and recall show how well the model predicts survival and non-survival.
