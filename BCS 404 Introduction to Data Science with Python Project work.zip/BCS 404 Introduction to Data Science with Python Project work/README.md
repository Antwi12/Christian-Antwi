# Titanic Data Science Project

## Exploratory Data Analysis, Statistical Analysis and Machine Learning Using the Titanic Dataset

This project was completed for **BCS 404: Introduction to Data Science with Python** at **Accra Technical University, Department of Computer Science**.

- **Student name:** `[Antwi Christian]`
- **Index number:** `[01259881B]`
- **Programme/Class:** `[Computer Scienece Btech Top Up 300 ]`
- **Lecturer:** Dr. Joseph Dadzie
- **Academic year:** 2025/2026 Second Semester

---

## Project Overview

The project analyses the Titanic passenger dataset using Python. It demonstrates data acquisition, data cleaning, exploratory data analysis, statistical analysis, data visualisation and introductory machine learning.

A Logistic Regression classifier was developed to predict whether a passenger survived the Titanic disaster. In the dataset, `Survived = 0` represents a passenger who did not survive, while `Survived = 1` represents a passenger who survived.

## Project Objectives

The main objectives were to:

1. Import and examine a real-world dataset.
2. Detect and handle missing values and duplicate observations.
3. visualise important patterns in the data.
4. Calculate and interpret descriptive and correlation statistics.
5. Identify variables associated with passenger survival.
6. Train and evaluate a Logistic Regression classification model.
7. Discuss the findings, limitations and possible improvements.

## Dataset

The project uses the Titanic `train.csv` dataset from Kaggle:

- **Source:** [Titanic — Machine Learning from Disaster](https://www.kaggle.com/competitions/titanic/data)
- **Original dimensions:** 891 observations and 12 columns
- **Target variable:** `Survived`

### Original Columns

| Column | Description |
|---|---|
| `PassengerId` | Unique passenger identifier |
| `Survived` | Survival outcome: 0 = No, 1 = Yes |
| `Pclass` | Passenger class: 1st, 2nd or 3rd |
| `Name` | Passenger's name |
| `Sex` | Passenger's sex |
| `Age` | Passenger's age in years |
| `SibSp` | Number of siblings or spouses aboard |
| `Parch` | Number of parents or children aboard |
| `Ticket` | Ticket number |
| `Fare` | Passenger fare |
| `Cabin` | Cabin number |
| `Embarked` | Port of embarkation: C, Q or S |

## Technologies and Libraries

The analysis uses:

- Python
- Jupyter Notebook
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-Learn

## Data Cleaning

The following preprocessing steps were performed:

1. Missing values were detected with Pandas.
2. The original dataset contained:
   - 177 missing `Age` values
   - 687 missing `Cabin` values
   - 2 missing `Embarked` values
3. Missing `Age` values were replaced with the median age within each passenger class.
4. Missing `Embarked` values were replaced with the mode.
5. The `Cabin` column was removed because most of its values were missing.
6. Duplicate observations were checked; no duplicate rows were found.
7. `Sex` and `Embarked` were converted into dummy variables for machine learning.

## Data Visualisations

The project includes:

1. Histogram of passenger ages
2. Bar chart of passenger-class distribution
3. Boxplot of age by passenger class
4. Scatter plot of Age versus Fare, coloured by survival
5. Correlation heatmap
6. Pairplot of selected numerical variables

## Important Statistical Findings

- The overall survival rate was approximately **38.4%**.
- Approximately **61.6%** of passengers did not survive.
- Female passengers had a survival rate of approximately **74.2%**.
- Male passengers had a survival rate of approximately **18.9%**.
- First-class passengers had a survival rate of approximately **63.0%**.
- Second-class passengers had a survival rate of approximately **47.3%**.
- Third-class passengers had a survival rate of approximately **24.2%**.
- The average passenger age after imputation was approximately **29.07 years**.
- The median passenger age was **26 years**.
- The average fare was approximately **32.20**.

### Correlation Findings

When correlations with the target variable `Survived` were considered:

- `Fare` had the strongest positive numerical correlation with survival: **0.257**.
- `Pclass` had the strongest negative numerical correlation with survival: **-0.338**.

Across the complete numerical correlation matrix:

- `SibSp` and `Parch` had the strongest positive correlation: approximately **0.415**.
- `Pclass` and `Fare` had the strongest negative correlation: approximately **-0.549**.

## Machine Learning Model

A Logistic Regression classifier was trained using these predictor variables:

- `Pclass`
- `Sex`
- `Age`
- `SibSp`
- `Parch`
- `Fare`
- `Embarked`

The cleaned data was divided into training and testing sets using an 80:20 split and `random_state=42`.

### Model Results

- **Test observations:** 179
- **Accuracy:** 81.56%
- **Confusion matrix:** `[[91, 14], [19, 55]]`

| Class | Precision | Recall | F1-score | Support |
|---|---:|---:|---:|---:|
| 0 — Did not survive | 0.83 | 0.87 | 0.85 | 105 |
| 1 — Survived | 0.80 | 0.74 | 0.77 | 74 |
| Macro average | 0.81 | 0.80 | 0.81 | 179 |
| Weighted average | 0.81 | 0.82 | 0.81 | 179 |

The model performed slightly better when predicting non-survivors than survivors. It correctly classified 146 of the 179 test observations.

## Repository Structure

```text
Titanic-Data-Science-Project/
├── README.md
├── Titanic_Analysis.ipynb
├── Titanic_Analysis.py                 # Optional Python script
├── train.csv                           # Include only where licensing permits
└── Titanic_Data_Science_Report_Revised.pdf
```

> Rename the files in this section if your actual notebook or script uses a different filename.

## Installation

Install the required Python libraries with:

```bash
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
```

Alternatively, create a `requirements.txt` file and run:

```bash
pip install -r requirements.txt
```

## Running the Project

1. Clone or download the GitHub repository.
2. Place `train.csv` in the same folder as the notebook, if it is not already included.
3. Open a terminal in the project folder.
4. Start Jupyter Notebook:

```bash
jupyter notebook
```

5. Open `Titanic_Analysis.ipynb`.
6. Select **Kernel → Restart & Run All** to reproduce the analysis.

If a Python script is included, it can be executed with:

```bash
python Titanic_Analysis.py
```

## Limitations

- The `Cabin` column was removed because it contained many missing values, although cabin location might have provided useful information.
- Missing ages were estimated using median age by passenger class.
- Logistic Regression may not capture complex, non-linear relationships.
- Only a basic set of predictor variables was used.
- Performance was evaluated using one train-test split rather than cross-validation.

## Recommendations

Future work could:

- Extract passenger titles from names.
- Create family-size and travelling-alone variables.
- Group ages and fares into categories.
- Scale numerical variables.
- Use cross-validation and hyperparameter tuning.
- Compare Logistic Regression with Decision Tree, Random Forest, Gradient Boosting and Support Vector Machine models.

## Report

The complete written report is available in:

```text
Titanic_Data_Science_Report_Revised.pdf
```

## References

- Kaggle. [Titanic — Machine Learning from Disaster](https://www.kaggle.com/competitions/titanic/data)
- McKinney, W. (2010). *Data Structures for Statistical Computing in Python*.
- Pedregosa, F. et al. (2011). *Scikit-learn: Machine Learning in Python*.
- Waskom, M. L. (2021). *Seaborn: Statistical Data Visualization*.

## Author

**[Antwi Christian]**  
Accra Technical University  
Department of Computer Science
