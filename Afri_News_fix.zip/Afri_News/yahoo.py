from flask import Flask, jsonify
from flask_cors import CORS
import feedparser
import re
import requests
from urllib.parse import urlparse
import time

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

def extract_image_from_content(content):
    """Extract image URL from HTML content - simplified version"""
    if not content:
        return None
    
    # Look for img tags in the content
    img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\'][^>]*>', content, re.IGNORECASE)
    if img_match and img_match.group(1):
        return img_match.group(1)
    
    # Look for direct image URLs
    url_match = re.search(r'https?://[^\s<>"\']+\.(?:jpg|jpeg|png|gif|webp)', content, re.IGNORECASE)
    if url_match and url_match.group(0):
        return url_match.group(0)
    
    return None



def get_rss2json_data(rss_url):
    """Get data from RSS2JSON API - simplified version"""
    try:
        rss2json_url = f"https://api.rss2json.com/v1/api.json?rss_url={rss_url}"
        response = requests.get(rss2json_url, timeout=10)
        data = response.json()
        
        items = data.get('items', [])
        processed_items = []
        
        for item in items:
            # Clean description
            description = item.get('description', '')
            if description:
                # Remove HTML tags for clean description
                clean_desc = re.sub(r'<[^>]+>', '', description)
                clean_desc = clean_desc[:150] + "..." if len(clean_desc) > 150 else clean_desc
            else:
                clean_desc = "No description available."
            
            # Simple image extraction
            image_url = None
            
            # Check for existing enclosure
            if item.get('enclosure') and item['enclosure'].get('link'):
                image_url = item['enclosure']['link']
            # Extract from description
            elif description:
                image_url = extract_image_from_content(description)
            # Check for thumbnail
            elif item.get('thumbnail'):
                image_url = item['thumbnail']
            
            processed_item = {
                'title': item.get('title', 'No title'),
                'link': item.get('link', ''),
                'pubDate': item.get('pubDate', ''),
                'published': item.get('pubDate', ''),
                'description': clean_desc,
                'image': image_url,
                'enclosure': {'link': image_url} if image_url else None
            }
            
            processed_items.append(processed_item)
        
        return processed_items
        
    except Exception as e:
        print(f"RSS2JSON Error: {e}")
        return []

def parse_feed_with_images(feed_url, limit=15):
    """Parse RSS feed with enhanced image extraction"""
    try:
        feed = feedparser.parse(feed_url)
        processed_items = []
        
        for entry in feed.entries[:limit]:
            image_url = None
            
            # Try multiple methods to get image
            # Method 1: media_thumbnail
            if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
                if isinstance(entry.media_thumbnail, list) and len(entry.media_thumbnail) > 0:
                    candidate = entry.media_thumbnail[0].get('url', '')
                    if validate_image_url(candidate):
                        image_url = candidate
            
            # Method 2: media_content
            if not image_url and hasattr(entry, 'media_content') and entry.media_content:
                if isinstance(entry.media_content, list):
                    for media in entry.media_content:
                        if media.get('type', '').startswith('image'):
                            candidate = media.get('url', '')
                            if validate_image_url(candidate):
                                image_url = candidate
                                break
            
            # Method 3: enclosures
            if not image_url and hasattr(entry, 'enclosures') and entry.enclosures:
                for enclosure in entry.enclosures:
                    if hasattr(enclosure, 'type') and enclosure.type and enclosure.type.startswith('image'):
                        candidate = getattr(enclosure, 'href', '')
                        if validate_image_url(candidate):
                            image_url = candidate
                            break
            
            # Method 4: extract from summary/content
            if not image_url:
                for content_field in ['summary', 'content', 'description']:
                    if hasattr(entry, content_field):
                        content = getattr(entry, content_field)
                        if isinstance(content, list):
                            content = ' '.join([str(c) for c in content])
                        elif hasattr(content, 'value'):
                            content = content.value
                        
                        candidate = extract_image_from_content(str(content))
                        if candidate and validate_image_url(candidate):
                            image_url = candidate
                            break
            
            # Get description and clean HTML
            description = ""
            if hasattr(entry, 'summary'):
                description = re.sub(r'<[^>]+>', '', entry.summary)
                description = description[:200] + "..." if len(description) > 200 else description
            
            published_date = ""
            if hasattr(entry, 'published'):
                published_date = entry.published
            elif hasattr(entry, 'updated'):
                published_date = entry.updated
            
            processed_items.append({
                'title': getattr(entry, 'title', 'No title'),
                'link': getattr(entry, 'link', ''),
                'published': published_date,
                'pubDate': published_date,
                'description': description,
                'image': image_url,
                'enclosure': {'link': image_url} if image_url else None
            })
        
        return processed_items
        
    except Exception as e:
        print(f"Feed parsing error: {e}")
        return []

@app.route('/api/news')
def get_news():
    """Get Yahoo RSS news with images - simplified version"""
    try:
        rss_url = "https://news.yahoo.com/rss/"
        feed = feedparser.parse(rss_url)
        news_items = []
        
        for entry in feed.entries[:15]:
            # Try to get image from multiple sources
            image_url = None
            
            # Method 1: Check for media_thumbnail
            if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
                image_url = entry.media_thumbnail[0]['url']
            
            # Method 2: Check for enclosures
            elif hasattr(entry, 'enclosures') and entry.enclosures:
                for enclosure in entry.enclosures:
                    if enclosure.type and enclosure.type.startswith('image'):
                        image_url = enclosure.href
                        break
            
            # Method 3: Extract from summary/content
            elif hasattr(entry, 'summary'):
                image_url = extract_image_from_content(entry.summary)
            
            # Method 4: Check for media_content
            elif hasattr(entry, 'media_content') and entry.media_content:
                image_url = entry.media_content[0]['url']
            
            # Get description and clean HTML
            description = ""
            if hasattr(entry, 'summary'):
                description = re.sub(r'<[^>]+>', '', entry.summary)
                description = description[:150] + "..." if len(description) > 150 else description
            
            news_items.append({
                'title': entry.title,
                'link': entry.link,
                'published': entry.published,
                'pubDate': entry.published,
                'description': description,
                'image': image_url,
                'enclosure': {'link': image_url} if image_url else None
            })
        
        return jsonify(news_items)
        
    except Exception as e:
        print(f"Yahoo RSS Error: {e}")
        return jsonify([])

@app.route('/api/google-news/<category>')
def get_google_news(category):
    """Get Google News RSS with enhanced image extraction"""
    try:
        # Build Google RSS URL with better query
        category_queries = {
            'business': 'business OR finance OR economy OR market',
            'sports': 'sports OR football OR basketball OR soccer',
            'technology': 'technology OR tech OR AI OR software',
            'entertainment': 'entertainment OR movies OR music OR celebrity'
        }
        
        query = category_queries.get(category, category)
        google_rss = f"https://news.google.com/rss/search?q={query}&hl=en-GH&gl=GH&ceid=GH:en"
        
        # Try RSS2JSON first (better for Google News)
        items = get_rss2json_data(google_rss)
        
        if items and len(items) > 0:
            return jsonify(items)
        
        # Fallback to direct RSS parsing
        fallback_items = parse_feed_with_images(google_rss, 15)
        return jsonify(fallback_items)
        
    except Exception as e:
        print(f"Google News Error for {category}: {e}")
        return jsonify([])

@app.route('/api/search/<query>')
def search_news(query):
    """Search Google News with enhanced image extraction"""
    try:
        # Enhance query for better results
        enhanced_query = f"{query} news"
        search_rss = f"https://news.google.com/rss/search?q={enhanced_query}&hl=en-GH&gl=GH&ceid=GH:en"
        
        # Try RSS2JSON first
        items = get_rss2json_data(search_rss)
        
        if items and len(items) > 0:
            return jsonify(items)
        
        # Fallback to direct parsing
        fallback_items = parse_feed_with_images(search_rss, 15)
        return jsonify(fallback_items)
        
    except Exception as e:
        print(f"Search Error for '{query}': {e}")
        return jsonify([])

# Health check endpoint
@app.route('/api/health')
def health_check():
    return jsonify({"status": "healthy", "timestamp": time.time()})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)