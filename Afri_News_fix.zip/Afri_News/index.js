// Buttons
const generalBtn = document.getElementById("genral");
const businessBtn = document.getElementById("business");
const sportsBtn = document.getElementById("sport");
const entertainmentBtn = document.getElementById("entertainment");
const technologyBtn = document.getElementById("technology");
const searchBtn = document.getElementById("searchBtn");
const darkToggle = document.getElementById("darkToggle");

// Input/Output
const newsQuery = document.getElementById("newsQuery");
const newsType = document.getElementById("newsType");
const newsdetails = document.getElementById("newsdetails");

// News store
let newsDataArr = [];

// API Configuration
const API_BASE = 'http://localhost:5000/api'; // Change to your deployed URL

// Dark mode functionality
darkToggle.addEventListener("click", () => {
    document.body.classList.toggle('dark-mode');
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => card.classList.toggle('dark-mode'));
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => alert.classList.toggle('dark-mode'));
});

// Google News RSS categories
const categoryMap = {
    general: "general",
    business: "business",
    sports: "sports",
    entertainment: "entertainment",
    technology: "technology"
};

// RSS2JSON endpoint (fallback)
function buildGoogleRSS(category) {
    const googleRSS = `https://news.google.com/rss/search?q=${category}&hl=en-GH&gl=GH&ceid=GH:en`;
    return `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(googleRSS)}`;
}

// Show loading spinner
function showLoading() {
    newsdetails.innerHTML = `
        <div class="col-12">
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    `;
}

// 👇 Category buttons
generalBtn.addEventListener("click", () => fetchNews("general"));
businessBtn.addEventListener("click", () => fetchNews("business"));
sportsBtn.addEventListener("click", () => fetchNews("sports"));
technologyBtn.addEventListener("click", () => fetchNews("technology"));
entertainmentBtn.addEventListener("click", () => fetchNews("entertainment"));

// 🔍 Search bar
searchBtn.addEventListener("click", () => {
    const query = newsQuery.value.trim();
    if (!query) return;
    newsType.innerHTML = `<h4>Search: ${query}</h4>`;
    fetchSearchNews(query);
});

// Enter key for search
newsQuery.addEventListener("keypress", (e) => {
    if (e.key === 'Enter') {
        searchBtn.click();
    }
});

// 📰 Load default
window.onload = () => {
    newsType.innerHTML = "<h4>Top Headlines</h4>";
    fetchNews("general");
};

// Enhanced image extraction function
function extractImageFromContent(content) {
    if (!content) return null;
    
    // Look for img tags
    const imgMatch = content.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
    if (imgMatch && imgMatch[1]) {
        return imgMatch[1];
    }
    
    // Look for direct image URLs
    const urlMatch = content.match(/https?:\/\/[^\s<>"']+\.(?:jpg|jpeg|png|gif|webp|svg)/i);
    if (urlMatch && urlMatch[0]) {
        return urlMatch[0];
    }
    
    // Look for media URLs in various formats
    const mediaMatch = content.match(/https?:\/\/[^\s<>"']*(?:media|images|thumb|cdn)[^\s<>"']*\.(?:jpg|jpeg|png|gif|webp)/i);
    if (mediaMatch && mediaMatch[0]) {
        return mediaMatch[0];
    }
    
    return null;
}

// Enhanced RSS2JSON fallback with better image handling
async function fetchGoogleRSSWithImages(category) {
    try {
        const url = buildGoogleRSS(categoryMap[category]);
        const response = await fetch(url);
        const data = await response.json();
        
        if (!data.items) {
            newsDataArr = [];
            displayNews();
            return;
        }
        
        // Process each item to extract images better
        const processedItems = await Promise.all(data.items.map(async (item) => {
            let imageUrl = null;
            
            // Try multiple sources for images
            if (item.enclosure && item.enclosure.link) {
                imageUrl = item.enclosure.link;
            } else if (item.thumbnail) {
                imageUrl = item.thumbnail;
            } else if (item.description) {
                imageUrl = extractImageFromContent(item.description);
            } else if (item.content) {
                imageUrl = extractImageFromContent(item.content);
            }
            
            // If still no image, try to fetch one from the article source
            if (!imageUrl && item.link) {
                // For Google News, try to extract from the source link
                try {
                    const articleResponse = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(item.link)}`);
                    // This might not work due to CORS, but it's worth a try
                } catch (e) {
                    // Ignore errors, we'll use placeholder
                }
            }
            
            return {
                ...item,
                image: imageUrl,
                enclosure: imageUrl ? { link: imageUrl } : null
            };
        }));
        
        newsDataArr = processedItems;
        displayNews();
    } catch (error) {
        console.error('Error fetching news:', error);
        newsdetails.innerHTML = "<h5>Error loading news. Please try again later.</h5>";
    }
}

// 🔄 Fetch News (tries Flask first, fallbacks to RSS2JSON)
async function fetchNews(category) {
    try {
        showLoading();
        
        // Set category title
        const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
        if (category === "general") {
            newsType.innerHTML = `<h4>Top Headlines</h4>`;
        } else {
            newsType.innerHTML = `<h4>${categoryTitle} News</h4>`;
        }
        
        // Try Flask backend first
        if (category === "general") {
            try {
                const response = await fetch(`${API_BASE}/news`);
                if (response.ok) {
                    const data = await response.json();
                    newsDataArr = data;
                    displayNews();
                    return;
                }
            } catch (fetchError) {
                console.log('Flask backend not available for general news');
            }
            
            // For general/home, if Flask fails, use Yahoo RSS directly via RSS2JSON
            const yahooRSS = "https://news.yahoo.com/rss/";
            const rss2jsonUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(yahooRSS)}`;
            
            try {
                const response = await fetch(rss2jsonUrl);
                const data = await response.json();
                newsDataArr = data.items || [];
                displayNews();
                return;
            } catch (rssError) {
                console.error('RSS2JSON also failed:', rssError);
                newsdetails.innerHTML = "<h5>Error loading news. Please try again later.</h5>";
                return;
            }
        } else {
            // For other categories, try Flask backend first
            try {
                const response = await fetch(`${API_BASE}/google-news/${category}`);
                if (response.ok) {
                    const data = await response.json();
                    newsDataArr = data;
                    displayNews();
                    return;
                }
            } catch (fetchError) {
                console.log('Flask backend not available for category:', category);
            }
            
            // Fallback to Google RSS via RSS2JSON
            await fetchGoogleRSSWithImages(category);
        }
        
    } catch (error) {
        console.error('Error fetching news:', error);
        newsdetails.innerHTML = "<h5>Error loading news. Please try again later.</h5>";
    }
}

// 🔎 Search News
async function fetchSearchNews(query) {
    try {
        showLoading();
        
        // Try Flask backend first
        const response = await fetch(`${API_BASE}/search/${encodeURIComponent(query)}`);
        if (response.ok) {
            const data = await response.json();
            newsDataArr = data;
            displayNews();
            return;
        }
        
        // Fallback to RSS2JSON
        await fetchGoogleSearch(query);
        
    } catch (error) {
        console.log('Flask backend not available, using RSS2JSON fallback');
        await fetchGoogleSearch(query);
    }
}

// 🔄 Category Fetch (RSS2JSON fallback) - kept for compatibility
async function fetchGoogleCategory(category) {
    await fetchGoogleRSSWithImages(category);
}

// 🔎 Search Fetch (RSS2JSON fallback)
async function fetchGoogleSearch(query) {
    try {
        const searchRSS = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-GH&gl=GH&ceid=GH:en`;
        const url = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(searchRSS)}`;
        const response = await fetch(url);
        const data = await response.json();
        
        // Enhanced processing for search results too
        const processedItems = data.items ? data.items.map(item => {
            let imageUrl = null;
            
            if (item.enclosure && item.enclosure.link) {
                imageUrl = item.enclosure.link;
            } else if (item.thumbnail) {
                imageUrl = item.thumbnail;
            } else if (item.description) {
                imageUrl = extractImageFromContent(item.description);
            } else if (item.content) {
                imageUrl = extractImageFromContent(item.content);
            }
            
            return {
                ...item,
                image: imageUrl,
                enclosure: imageUrl ? { link: imageUrl } : null
            };
        }) : [];
        
        newsDataArr = processedItems;
        displayNews();
    } catch (error) {
        console.error('Error searching news:', error);
        newsdetails.innerHTML = "<h5>Error searching news. Please try again later.</h5>";
    }
}

// Image preloader function
function preloadImage(src) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(src);
        img.onerror = () => reject();
        img.src = src;
        // Add timeout to prevent hanging
        setTimeout(() => reject(), 5000);
    });
}

// 🖼️ Renderer with Image Support and Preloading
async function displayNews() {
    newsdetails.innerHTML = "";

    if (newsDataArr.length === 0) {
        const alertClass = document.body.classList.contains('dark-mode') ? 'alert alert-info dark-mode' : 'alert alert-info';
        newsdetails.innerHTML = `<div class='col-12'><div class='${alertClass}'><h5>No news found.</h5></div></div>`;
        return;
    }

    // Create all cards first with placeholder images
    const cardPromises = newsDataArr.map(async (news, index) => {
        // Handle different date formats
        let pubDate = "Unknown date";
        if (news.pubDate) {
            pubDate = news.pubDate.split(" ")[0];
        } else if (news.published) {
            pubDate = new Date(news.published).toLocaleDateString();
        }

        const col = document.createElement("div");
        col.className = "col-sm-12 col-md-6 col-lg-4 col-xl-3 p-2";

        const card = document.createElement("div");
        card.className = document.body.classList.contains('dark-mode') ? "card h-100 shadow-sm dark-mode" : "card h-100 shadow-sm";

        // Image handling with multiple fallbacks and preloading
        const image = document.createElement("img");
        image.className = "card-img-top news-image";
        image.setAttribute("alt", news.title);
        
        // Try different image sources with better extraction
        let imageUrl = null;
        
        // Priority order for image sources
        if (news.image && news.image !== "default.jpg" && !news.image.includes("placeholder")) {
            imageUrl = news.image;
        } else if (news.enclosure && news.enclosure.link && news.enclosure.link !== "default.jpg") {
            imageUrl = news.enclosure.link;
        } else if (news.thumbnail && news.thumbnail !== "default.jpg") {
            imageUrl = news.thumbnail;
        } else if (news.description) {
            imageUrl = extractImageFromContent(news.description);
        } else if (news.content) {
            imageUrl = extractImageFromContent(news.content);
        }
        
        // Set loading placeholder first
        image.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23f8f9fa'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' fill='%236c757d'%3ELoading...%3C/text%3E%3C/svg%3E";
        
        // Try to preload the actual image
        if (imageUrl) {
            try {
                await preloadImage(imageUrl);
                image.src = imageUrl;
            } catch (error) {
                // If preload fails, set fallback
                image.src = "https://via.placeholder.com/300x200/6c757d/ffffff?text=Image+Not+Available";
            }
        } else {
            image.src = "https://via.placeholder.com/300x200/6c757d/ffffff?text=No+Image";
        }
        
        // Additional error handling
        image.onerror = function() {
            this.src = "https://via.placeholder.com/300x200/6c757d/ffffff?text=Image+Error";
        };

        const cardBody = document.createElement("div");
        cardBody.className = "card-body d-flex flex-column";

        const newsHeading = document.createElement("h6");
        newsHeading.className = "card-title";
        newsHeading.innerHTML = news.title;

        const dateHeading = document.createElement("small");
        dateHeading.className = "text-primary mb-2";
        dateHeading.innerHTML = pubDate;

        const description = document.createElement("p");
        description.className = "card-text text-muted flex-grow-1";
        // Clean HTML from description
        let cleanDescription = news.description || "No description available.";
        cleanDescription = cleanDescription.replace(/<[^>]*>/g, '');
        description.innerHTML = cleanDescription;

        const link = document.createElement("a");
        link.className = "btn btn-dark btn-sm mt-auto";
        link.setAttribute("target", "_blank");
        link.setAttribute("rel", "noopener noreferrer");
        link.href = news.link;
        link.innerHTML = "Read more";

        cardBody.appendChild(newsHeading);
        cardBody.appendChild(dateHeading);
        cardBody.appendChild(description);
        cardBody.appendChild(link);

        card.appendChild(image);
        card.appendChild(cardBody);
        col.appendChild(card);
        
        return col;
    });

    // Wait for all cards to be ready and append them
    const cards = await Promise.all(cardPromises);
    cards.forEach(card => newsdetails.appendChild(card));
}